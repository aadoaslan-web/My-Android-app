package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.SimulatorTab
import com.example.ui.EngineViewModel
import com.example.ui.components.AssemblyWorkbench
import com.example.ui.components.ControlPanel
import com.example.ui.components.DiagnosticsView
import com.example.ui.components.ListerEngineCanvas
import com.example.ui.components.TopBarControls
import com.example.ui.theme.ListerEngineTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ListerEngineTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ListerEngineApp()
                }
            }
        }
    }
}

@Composable
fun ListerEngineApp(viewModel: EngineViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopBarControls(
                state = uiState,
                onStartCrank = { viewModel.startCrankHandle() },
                onStopEngine = { viewModel.stopEngine() },
                onToggleDecompression = { viewModel.toggleDecompressionLever() },
                onToggleFuelValve = { viewModel.toggleFuelValve() },
                onRefillFuel = { viewModel.refillFuel() },
                onSelectCylinderConfig = { viewModel.setCylinderConfig(it) },
                onSelectTab = { viewModel.selectTab(it) },
                onToggleLanguage = { viewModel.toggleLanguage() }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.activeTab) {
                SimulatorTab.CUTAWAY -> {
                    ListerEngineCanvas(
                        state = uiState,
                        onComponentClick = { viewModel.toggleComponent(it) },
                        onToggleTelemetryExpanded = { viewModel.toggleTelemetryDashboard() },
                        onToggleRpm = { viewModel.toggleRpmCurve() },
                        onToggleFuel = { viewModel.toggleFuelCurve() },
                        onToggleTorque = { viewModel.toggleTorqueCurve() }
                    )
                }
                SimulatorTab.CONTROL_PANEL -> {
                    ControlPanel(
                        state = uiState,
                        onLoadChange = { viewModel.setElectricalLoad(it) },
                        onToggleBreaker = { viewModel.toggleCircuitBreaker() }
                    )
                }
                SimulatorTab.WORKBENCH -> {
                    AssemblyWorkbench(
                        state = uiState,
                        onToggleComponent = { viewModel.toggleComponent(it) },
                        onReassembleAll = { viewModel.reassembleAllComponents() },
                        onSelectDetails = { viewModel.selectComponentDetails(it) }
                    )
                }
                SimulatorTab.DIAGNOSTICS -> {
                    DiagnosticsView(
                        state = uiState,
                        logsFlow = viewModel.maintenanceLogs
                    )
                }
            }
        }
    }
}
