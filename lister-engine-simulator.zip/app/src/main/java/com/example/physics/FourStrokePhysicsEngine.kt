package com.example.physics

import com.example.model.CylinderConfig
import com.example.model.EngineFourStrokePhase
import com.example.model.EngineState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * High-fidelity 4-Stroke Single & Twin Cylinder Diesel Physics Engine.
 * Models gas pressure dynamics, slider-crank kinematics, indicated & load torque,
 * mechanical friction, and centrifugal governor feedback loop.
 */
class FourStrokePhysicsEngine {

    companion object {
        // Lister CS 6/1 Single Cylinder Specification Constants
        private const val BORE_M = 0.1143f        // 4.5 inches bore
        private const val STROKE_M = 0.1397f      // 5.5 inches stroke
        private const val PISTON_AREA = (PI * (BORE_M / 2.0) * (BORE_M / 2.0)).toFloat() // ~0.01026 m^2
        private const val CRANK_RADIUS_M = STROKE_M / 2.0f // 0.06985 m
        private const val CONROD_LENGTH_M = 0.2794f        // 11 inches connecting rod
        private const val COMPRESSION_RATIO = 17.5f
        private const val DISPLACEMENT_M3 = PISTON_AREA * STROKE_M // ~0.001433 m^3 (1.43L)
        
        private const val P_ATM_BAR = 1.013f
        private const val BAR_TO_PASCAL = 100000.0f

        // Heavy flywheel moment of inertia (Lister twin cast iron flywheels)
        private const val FLYWHEEL_INERTIA_SINGLE = 2.8f // kg*m^2
        private const val FLYWHEEL_INERTIA_TWIN = 4.6f   // kg*m^2
    }

    data class PhysicsStepResult(
        val newRpm: Float,
        val newCrankAngle: Float,
        val instantaneousTorqueNm: Float,
        val cylinder1PressureBar: Float,
        val cylinder2PressureBar: Float,
        val loadTorqueNm: Float,
        val brakeHorsePower: Float,
        val bmepBar: Float,
        val governorThrottlePercent: Float,
        val phase: EngineFourStrokePhase,
        val thermalEfficiencyPercent: Float
    )

    /**
     * Executes one numerical time step (dt seconds) of the 4-stroke cycle dynamics.
     */
    fun update(state: EngineState, dt: Float): PhysicsStepResult {
        val dtCoerced = dt.coerceIn(0.0005f, 0.05f)
        val numCylinders = if (state.cylinderConfig == CylinderConfig.TWIN) 2 else 1
        val flywheelInertia = if (numCylinders == 2) FLYWHEEL_INERTIA_TWIN else FLYWHEEL_INERTIA_SINGLE

        var currentRpm = state.rpm
        val currentAngle = state.crankAngleDegrees % 720f

        // --- 1. Governor & Throttle Regulation ---
        var throttle = state.governorThrottlePercent
        val isRunning = state.isEngineRunning && state.canStart

        if (isRunning) {
            if (state.isGovernorAttached) {
                // Centrifugal flyweight governor PID reaction
                val rpmError = state.targetRpm - currentRpm
                val loadCompensation = (state.electricalLoadWatts / 4500f) * 45f
                val targetThrottle = (35f + loadCompensation + (rpmError * 0.25f)).coerceIn(10f, 100f)
                throttle += (targetThrottle - throttle) * (dtCoerced * 4.5f)
            } else {
                // Throttle stays fixed or oscillations occur
                throttle = 75f
            }
        } else {
            throttle = 15f
        }

        // --- 2. Cylinder Pressure & Indicated Torque Calculation ---
        val cyl1Result = calculateCylinderDynamics(
            crankAngleDeg = currentAngle,
            throttlePercent = throttle,
            isRunning = isRunning,
            isDecompressed = state.isDecompressionLeverRaised,
            fuelOpen = state.isFuelValveOpen && state.fuelLevelPercent > 0.1f,
            rpm = currentRpm
        )

        val cyl2Result = if (numCylinders == 2) {
            // Cylinder 2 offset by 360 degrees in 4-stroke cycle
            calculateCylinderDynamics(
                crankAngleDeg = (currentAngle + 360f) % 720f,
                throttlePercent = throttle,
                isRunning = isRunning,
                isDecompressed = state.isDecompressionLeverRaised,
                fuelOpen = state.isFuelValveOpen && state.fuelLevelPercent > 0.1f,
                rpm = currentRpm
            )
        } else {
            CylinderDynamics(pressureBar = P_ATM_BAR, torqueNm = 0f)
        }

        val totalIndicatedTorque = cyl1Result.torqueNm + cyl2Result.torqueNm

        // --- 3. Resistive & Load Torques ---
        // Friction torque (Bearing friction + piston ring drag)
        val frictionTorque = 4.5f + (currentRpm / 600f) * 3.5f + (if (state.isGovernorAttached) 0.5f else 0.2f)
        
        // Pumping torque losses during non-power strokes
        val pumpingTorque = if (state.isExhaustAttached) 1.2f else 2.5f

        // Electrical Load Torque from Generator (P_elec / omega)
        val omegaRadPerSec = (currentRpm * 2.0f * PI / 60.0).toFloat().coerceAtLeast(0.1f)
        val generatorEfficiency = 0.82f
        val actualElectricalLoad = if (state.isCircuitBreakerClosed && state.isAlternatorBeltAttached && currentRpm > 150f) {
            state.electricalLoadWatts
        } else 0f

        val loadTorque = if (currentRpm > 50f) {
            (actualElectricalLoad / (omegaRadPerSec * generatorEfficiency)).coerceIn(0f, 65f)
        } else 0f

        // Net Torque acting on the crankshaft
        var netTorque = 0f
        if (isRunning) {
            netTorque = totalIndicatedTorque - frictionTorque - pumpingTorque - loadTorque
        } else if (state.isHandCrankingActive) {
            // Hand crank manual input torque (~35 Nm by human force)
            val humanTorque = if (state.isDecompressionLeverRaised) 42f else 18f
            netTorque = humanTorque - totalIndicatedTorque.coerceAtLeast(0f) - frictionTorque
        } else {
            // Friction deceleration coasting
            netTorque = -frictionTorque - (if (currentRpm > 20f) 8.0f else 2.0f)
        }

        // --- 4. Rotational Acceleration & Angular Velocity Integration ---
        // alpha = NetTorque / I
        val angularAccel = netTorque / flywheelInertia
        val newOmega = (omegaRadPerSec + angularAccel * dtCoerced).coerceAtLeast(0f)
        var newRpm = (newOmega * 60.0f / (2.0f * PI)).toFloat()

        if (!isRunning && !state.isHandCrankingActive && newRpm < 8f) {
            newRpm = 0f
        }

        // Angle progression
        val deltaAngle = (newRpm / 60f) * 360f * dtCoerced
        val newCrankAngle = (state.crankAngleDegrees + deltaAngle) % 720f

        // --- 5. Derived Performance Metrics ---
        val brakeTorque = (totalIndicatedTorque - frictionTorque - pumpingTorque).coerceAtLeast(0f)
        val brakePowerKw = (brakeTorque * newOmega) / 1000f
        val brakeHorsePower = brakePowerKw * 1.34102f

        // Brake Mean Effective Pressure (BMEP = 4 * PI * T / V_displacement)
        val totalDisplacement = DISPLACEMENT_M3 * numCylinders
        val bmepPascal = (4.0f * PI.toFloat() * brakeTorque) / totalDisplacement
        val bmepBar = (bmepPascal / BAR_TO_PASCAL).coerceIn(0f, 12f)

        val currentPhase = when (((newCrankAngle % 720f) + 720f) % 720f) {
            in 0f..180f -> EngineFourStrokePhase.INTAKE
            in 180f..360f -> EngineFourStrokePhase.COMPRESSION
            in 360f..540f -> EngineFourStrokePhase.POWER
            else -> EngineFourStrokePhase.EXHAUST
        }

        val thermalEfficiency = if (isRunning && brakeHorsePower > 0.1f) {
            (28.5f + (throttle / 100f) * 6.5f - (state.temperatureCelsius - 80f).coerceAtLeast(0f) * 0.1f).coerceIn(15f, 38f)
        } else 0f

        return PhysicsStepResult(
            newRpm = newRpm,
            newCrankAngle = newCrankAngle,
            instantaneousTorqueNm = totalIndicatedTorque,
            cylinder1PressureBar = cyl1Result.pressureBar,
            cylinder2PressureBar = cyl2Result.pressureBar,
            loadTorqueNm = loadTorque,
            brakeHorsePower = brakeHorsePower,
            bmepBar = bmepBar,
            governorThrottlePercent = throttle,
            phase = currentPhase,
            thermalEfficiencyPercent = thermalEfficiency
        )
    }

    private data class CylinderDynamics(val pressureBar: Float, val torqueNm: Float)

    /**
     * Calculates instantaneous gas pressure and slider-crank geometric torque for a single cylinder
     * based on position in the 720° 4-stroke cycle.
     */
    private fun calculateCylinderDynamics(
        crankAngleDeg: Float,
        throttlePercent: Float,
        isRunning: Boolean,
        isDecompressed: Boolean,
        fuelOpen: Boolean,
        rpm: Float
    ): CylinderDynamics {
        val angleRad = Math.toRadians(crankAngleDeg.toDouble()).toFloat()
        
        // Instantaneous cylinder volume V(theta) using slider-crank formula
        val r = CRANK_RADIUS_M
        val l = CONROD_LENGTH_M
        val lambda = r / l

        // Piston displacement from TDC
        val s = r * (1.0f - cos(angleRad) + (lambda / 2.0f) * (sin(angleRad).pow(2))).toFloat()
        val vClearance = DISPLACEMENT_M3 / (COMPRESSION_RATIO - 1.0f)
        val currentVolume = vClearance + PISTON_AREA * s
        val vMax = vClearance + DISPLACEMENT_M3

        var pressureBar = P_ATM_BAR

        when (crankAngleDeg) {
            // Intake Stroke (0° - 180°): Piston moving down, pulling fresh air
            in 0f..180f -> {
                pressureBar = 0.96f
            }
            // Compression Stroke (180° - 360°): Piston moving up, compressing air
            in 180f..360f -> {
                if (isDecompressed) {
                    // Decompression lever open -> air escapes through exhaust/intake valve
                    pressureBar = 1.05f
                } else {
                    // Polytropic compression P * V^gamma = const (gamma = 1.34)
                    val vRatio = (vMax / currentVolume).coerceAtLeast(1.0f)
                    pressureBar = P_ATM_BAR * vRatio.pow(1.34f)
                }
            }
            // Power / Expansion Stroke (360° - 540°): Fuel ignition & expansion
            in 360f..540f -> {
                if (isDecompressed) {
                    pressureBar = 1.0f
                } else if (isRunning && fuelOpen && rpm > 80f) {
                    // Diesel Combustion expansion curve
                    val expansionProgress = (crankAngleDeg - 360f) / 180f // 0.0 to 1.0
                    val peakPressure = 34.0f + (throttlePercent / 100f) * 38.0f // Up to ~72 bar peak!
                    
                    if (expansionProgress < 0.15f) {
                        // Rapid combustion pressure rise near TDC
                        val riseFactor = expansionProgress / 0.15f
                        pressureBar = 30.0f + (peakPressure - 30.0f) * sin(riseFactor * (PI.toFloat() / 2.0f))
                    } else {
                        // Polytropic expansion decay P * V^1.3 = const
                        val decayFactor = ((expansionProgress - 0.15f) / 0.85f)
                        pressureBar = (peakPressure * (1.0f - 0.75f * decayFactor)).coerceAtLeast(1.8f)
                    }
                } else {
                    // Motoring expansion without combustion
                    val vRatio = (vMax / currentVolume).coerceAtLeast(1.0f)
                    pressureBar = (P_ATM_BAR * vRatio.pow(1.32f) * 0.7f).coerceAtLeast(P_ATM_BAR)
                }
            }
            // Exhaust Stroke (540° - 720°): Piston pushing exhaust gases out
            else -> {
                pressureBar = 1.15f
            }
        }

        // Geometric Torque conversion from cylinder pressure:
        // Force_piston = (P_cyl - P_atm) * Area
        // Torque = Force_piston * r * (sin(theta) + (lambda / 2) * sin(2*theta))
        val netPressurePascal = (pressureBar - P_ATM_BAR) * BAR_TO_PASCAL
        val pistonForceN = netPressurePascal * PISTON_AREA
        
        val sinTheta = sin(angleRad)
        val sin2Theta = sin(2.0f * angleRad)
        
        val geometricKinematicFactor = sinTheta + (lambda / 2.0f) * sin2Theta
        val torqueNm = pistonForceN * CRANK_RADIUS_M * geometricKinematicFactor

        return CylinderDynamics(
            pressureBar = pressureBar.coerceAtLeast(0.1f),
            torqueNm = torqueNm
        )
    }
}
