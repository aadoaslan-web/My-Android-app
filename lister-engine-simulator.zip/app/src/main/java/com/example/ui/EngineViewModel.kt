package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.DieselAudioEngine
import com.example.data.AppDatabase
import com.example.data.MaintenanceLog
import com.example.model.AppLanguage
import com.example.model.CylinderConfig
import com.example.model.EngineComponentType
import com.example.model.EngineState
import com.example.model.SimulatorTab
import com.example.model.TelemetryDataPoint
import com.example.physics.FourStrokePhysicsEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.sin

class EngineViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val maintenanceDao = db.maintenanceDao()
    private val audioEngine = DieselAudioEngine(application)
    private val physicsEngine = FourStrokePhysicsEngine()

    private val _uiState = MutableStateFlow(EngineState())
    val uiState: StateFlow<EngineState> = _uiState.asStateFlow()

    val maintenanceLogs = maintenanceDao.getAllLogs()

    private var huntingTime = 0f

    init {
        startPhysicsLoop()
    }

    private fun startPhysicsLoop() {
        viewModelScope.launch(Dispatchers.Default) {
            var lastTimeMs = System.currentTimeMillis()
            while (true) {
                val currentTimeMs = System.currentTimeMillis()
                val dt = ((currentTimeMs - lastTimeMs) / 1000f).coerceIn(0.001f, 0.04f)
                lastTimeMs = currentTimeMs

                updateEnginePhysics(dt)
                delay(16) // ~60 FPS update
            }
        }
    }

    private var telemetrySampleTimer = 0f

    private fun updateEnginePhysics(totalDt: Float) {
        _uiState.update { initialState ->
            var tempState = initialState
            val subStepDt = 0.004f // 4ms sub-steps for ultra-smooth 4-stroke motion
            var remaining = totalDt
            var latestPhysicsStep = physicsEngine.update(tempState, 0f)

            while (remaining > 0f) {
                val step = remaining.coerceAtMost(subStepDt)
                remaining -= step

                var currentFuel = tempState.fuelLevelPercent
                var isRunning = tempState.isEngineRunning

                if (isRunning) {
                    if (!tempState.canStart) {
                        isRunning = false
                    } else {
                        val consumptionRate = 0.05f * (1f + tempState.electricalLoadWatts / 2500f) * step
                        currentFuel = (currentFuel - consumptionRate).coerceAtLeast(0f)
                        if (currentFuel <= 0f) isRunning = false
                    }
                }

                latestPhysicsStep = physicsEngine.update(tempState.copy(isEngineRunning = isRunning, fuelLevelPercent = currentFuel), step)
                tempState = tempState.copy(
                    rpm = latestPhysicsStep.newRpm,
                    crankAngleDegrees = latestPhysicsStep.newCrankAngle,
                    fuelLevelPercent = currentFuel,
                    isEngineRunning = isRunning,
                    governorThrottlePercent = latestPhysicsStep.governorThrottlePercent
                )
            }

            var messageAr = tempState.diagnosticMessageAr
            var messageEn = tempState.diagnosticMessageEn
            if (tempState.isEngineRunning && !tempState.isGovernorAttached) {
                messageAr = "تحذير: منظم السرعة منزوع! دورات المحرك متذبذبة وغير مستقرة."
                messageEn = "WARNING: Governor detached! Engine RPM hunting erratically."
            } else if (!tempState.isEngineRunning && !tempState.canStart) {
                messageAr = "توقف المحرك بسبب غياب قطعة أساسية أو انقطاع الوقود!"
                messageEn = "Engine stalled due to missing component or fuel shutoff!"
            }

            // Thermal simulation
            val targetTemp = if (tempState.isEngineRunning) {
                val heatGen = 70f + (tempState.electricalLoadWatts / 5000f) * 45f
                val cooling = if (tempState.isFlywheelFanAttached) 30f else 5f
                (25f + heatGen - cooling).coerceIn(25f, 130f)
            } else 25f

            val temp = tempState.temperatureCelsius + (targetTemp - tempState.temperatureCelsius) * (totalDt * 0.05f)

            // Generator Outputs
            val breakerOpen = !tempState.isCircuitBreakerClosed || !tempState.isAlternatorBeltAttached
            val currentRpm = latestPhysicsStep.newRpm
            val voltage = if (currentRpm > 100f && !breakerOpen) {
                ((currentRpm / 600f) * 230f * (1.0f - (tempState.electricalLoadWatts / 45000f))).coerceIn(0f, 280f)
            } else 0f

            val frequency = if (currentRpm > 50f) (currentRpm / 600f) * 50f else 0f
            val amperage = if (voltage > 30f && !breakerOpen) {
                (tempState.electricalLoadWatts / voltage).coerceIn(0f, 40f)
            } else 0f

            val fuelRateLh = if (tempState.isEngineRunning && tempState.fuelLevelPercent > 0f) {
                ((currentRpm / 600f) * (0.85f + (latestPhysicsStep.governorThrottlePercent / 100f) * 1.55f)).coerceAtLeast(0.1f)
            } else 0f

            // Update Telemetry History
            telemetrySampleTimer += totalDt
            val newHistory = if (telemetrySampleTimer >= 0.15f) {
                telemetrySampleTimer = 0f
                val newPoint = TelemetryDataPoint(
                    timestampMs = System.currentTimeMillis(),
                    rpm = currentRpm,
                    fuelRateLh = fuelRateLh,
                    torqueNm = latestPhysicsStep.instantaneousTorqueNm.coerceAtLeast(0f),
                    cylinderPressureBar = latestPhysicsStep.cylinder1PressureBar
                )
                (tempState.telemetryHistory + newPoint).takeLast(60)
            } else {
                tempState.telemetryHistory
            }

            // Audio Sync
            audioEngine.updateState(
                rpm = currentRpm,
                crankAngleDegrees = latestPhysicsStep.newCrankAngle,
                exhaustAttached = tempState.isExhaustAttached,
                load = 0.5f + (tempState.electricalLoadWatts / 2500f)
            )

            tempState.copy(
                temperatureCelsius = temp,
                torqueNm = latestPhysicsStep.instantaneousTorqueNm,
                fuelRateLh = fuelRateLh,
                cylinder1PressureBar = latestPhysicsStep.cylinder1PressureBar,
                cylinder2PressureBar = latestPhysicsStep.cylinder2PressureBar,
                loadTorqueNm = latestPhysicsStep.loadTorqueNm,
                brakeHorsePower = latestPhysicsStep.brakeHorsePower,
                bmepBar = latestPhysicsStep.bmepBar,
                thermalEfficiencyPercent = latestPhysicsStep.thermalEfficiencyPercent,
                outputVoltage = voltage,
                outputFrequencyHz = frequency,
                outputAmperage = amperage,
                sootSmokeDensity = if (tempState.isEngineRunning) (if (tempState.isExhaustAttached) 0.15f else 0.85f) else 0f,
                vibrationIntensity = (currentRpm / 600f) * (if (tempState.isGovernorAttached) 0.15f else 0.55f),
                oilPressureBar = if (currentRpm > 100f) (2.5f + (currentRpm / 600f) * 1.5f).coerceAtMost(4.5f) else 0f,
                diagnosticMessageAr = messageAr,
                diagnosticMessageEn = messageEn,
                telemetryHistory = newHistory
            )
        }
    }

    fun toggleTelemetryDashboard() {
        _uiState.update { it.copy(isTelemetryDashboardExpanded = !it.isTelemetryDashboardExpanded) }
    }

    fun toggleRpmCurve() {
        _uiState.update { it.copy(showRpmCurve = !it.showRpmCurve) }
    }

    fun toggleFuelCurve() {
        _uiState.update { it.copy(showFuelCurve = !it.showFuelCurve) }
    }

    fun toggleTorqueCurve() {
        _uiState.update { it.copy(showTorqueCurve = !it.showTorqueCurve) }
    }

    fun toggleComponent(type: EngineComponentType) {
        val currentSet = _uiState.value.attachedComponents.toMutableSet()
        val isRemoving = currentSet.contains(type)

        if (isRemoving) {
            currentSet.remove(type)
        } else {
            currentSet.add(type)
        }

        val actionAr = if (isRemoving) "فك قطعة ${type.nameAr}" else "تركيب قطعة ${type.nameAr}"
        val actionEn = if (isRemoving) "Removed ${type.nameEn}" else "Installed ${type.nameEn}"

        _uiState.update { it.copy(attachedComponents = currentSet, selectedComponentForDetails = type) }

        viewModelScope.launch {
            maintenanceDao.insertLog(
                MaintenanceLog(
                    actionAr = actionAr,
                    actionEn = actionEn,
                    componentId = type.id,
                    engineRpm = _uiState.value.rpm,
                    statusSummary = if (_uiState.value.isEngineRunning) "محرك يعمل" else "محرك متوقف"
                )
            )
        }
    }

    fun reassembleAllComponents() {
        _uiState.update { it.copy(attachedComponents = EngineComponentType.values().toSet()) }
        viewModelScope.launch {
            maintenanceDao.insertLog(
                MaintenanceLog(
                    actionAr = "إعادة تركيب وتجميع كافة القطع بالكامل",
                    actionEn = "Reassembled all engine components",
                    componentId = "all",
                    engineRpm = _uiState.value.rpm,
                    statusSummary = "جاهز"
                )
            )
        }
    }

    fun toggleFuelValve() {
        _uiState.update { it.copy(isFuelValveOpen = !it.isFuelValveOpen) }
    }

    fun refillFuel() {
        _uiState.update { it.copy(fuelLevelPercent = 100f) }
    }

    fun toggleDecompressionLever() {
        _uiState.update { it.copy(isDecompressionLeverRaised = !it.isDecompressionLeverRaised) }
    }

    fun startCrankHandle() {
        if (_uiState.value.isEngineRunning) return
        viewModelScope.launch {
            _uiState.update { it.copy(isHandCrankingActive = true) }
            delay(1200) // Spin hand crank
            val state = _uiState.value
            if (state.canStart) {
                _uiState.update { 
                    it.copy(
                        isHandCrankingActive = false, 
                        isEngineRunning = true,
                        isDecompressionLeverRaised = false,
                        diagnosticMessageAr = "تم تشغيل المحرك بنجاح عن طريق الهندل!",
                        diagnosticMessageEn = "Engine successfully started via hand crank!"
                    ) 
                }
            } else {
                _uiState.update { 
                    it.copy(
                        isHandCrankingActive = false,
                        diagnosticMessageAr = "فشل التشغيل! تحقق من المحبس والقطغ الأساسية.",
                        diagnosticMessageEn = "Start failed! Check fuel tap and critical components."
                    )
                }
            }
        }
    }

    fun stopEngine() {
        _uiState.update { 
            it.copy(
                isEngineRunning = false,
                diagnosticMessageAr = "تم إيقاف المحرك يدويًا.",
                diagnosticMessageEn = "Engine manually stopped."
            )
        }
        audioEngine.stop()
    }

    fun setElectricalLoad(watts: Float) {
        _uiState.update { it.copy(electricalLoadWatts = watts.coerceIn(0f, 5000f)) }
    }

    fun toggleCircuitBreaker() {
        _uiState.update { it.copy(isCircuitBreakerClosed = !it.isCircuitBreakerClosed) }
    }

    fun setCylinderConfig(config: CylinderConfig) {
        _uiState.update { it.copy(cylinderConfig = config) }
    }

    fun selectTab(tab: SimulatorTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun toggleLanguage() {
        _uiState.update { 
            it.copy(language = if (it.language == AppLanguage.AR) AppLanguage.EN else AppLanguage.AR) 
        }
    }

    fun selectComponentDetails(type: EngineComponentType?) {
        _uiState.update { it.copy(selectedComponentForDetails = type) }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
    }
}
