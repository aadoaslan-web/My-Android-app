package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.EngineComponentType
import com.example.model.EngineFourStrokePhase
import com.example.model.EngineState
import com.example.ui.theme.IndustrialDarkBackground
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ListerEngineCanvas(
    state: EngineState,
    onComponentClick: (EngineComponentType) -> Unit,
    onToggleTelemetryExpanded: () -> Unit = {},
    onToggleRpm: () -> Unit = {},
    onToggleFuel: () -> Unit = {},
    onToggleTorque: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IndustrialDarkBackground)
            .testTag("lister_engine_canvas_container")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val width = size.width.toFloat()
                        val height = size.height.toFloat()
                        val centerX = width / 2f
                        val centerY = height / 2f + 30f

                        val cylinderTopY = centerY - 180f
                        // Decompression Lever / Cylinder Head area
                        if (offset.y in (cylinderTopY - 90f)..(cylinderTopY + 20f)) {
                            if (offset.x in (centerX - 90f)..(centerX + 90f)) {
                                onComponentClick(EngineComponentType.CYLINDER_HEAD)
                                return@detectTapGestures
                            }
                        }

                        // Injector hit
                        if (offset.y in (cylinderTopY - 120f)..(cylinderTopY - 50f)) {
                            onComponentClick(EngineComponentType.FUEL_INJECTOR)
                            return@detectTapGestures
                        }

                        // Fuel Tank hit (Right side)
                        if (offset.x > centerX + 120f && offset.y < centerY - 50f) {
                            onComponentClick(EngineComponentType.FUEL_TANK)
                            return@detectTapGestures
                        }

                        // Exhaust Silencer hit (Left side)
                        if (offset.x < centerX - 120f && offset.y < centerY - 50f) {
                            onComponentClick(EngineComponentType.EXHAUST_SYSTEM)
                            return@detectTapGestures
                        }

                        // Flywheel hit
                        if (offset.y > centerY - 40f && offset.y < centerY + 160f) {
                            onComponentClick(EngineComponentType.FLYWHEEL_FAN)
                            return@detectTapGestures
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height
            val centerX = width / 2f
            val centerY = height / 2f + 30f

            // Dynamic harmonic engine shaking vibration (smooth mechanical pulse)
            val vibX = if (state.isEngineRunning || state.isHandCrankingActive) {
                (sin(Math.toRadians((state.crankAngleDegrees * 2.5f).toDouble())).toFloat() * state.vibrationIntensity * 3.0f)
            } else 0f
            val vibY = if (state.isEngineRunning || state.isHandCrankingActive) {
                (cos(Math.toRadians((state.crankAngleDegrees * 2.5f).toDouble())).toFloat() * state.vibrationIntensity * 2.0f)
            } else 0f

            withTransform({
                translate(left = vibX, top = vibY)
            }) {
                // 1. Heavy Cast-Iron Base Plate & Crankcase Oil Sump
                drawBasePlate(centerX, centerY)

                val crankRad = Math.toRadians(state.crankAngleDegrees.toDouble())
                val crankRadius = 55f
                val conRodLength = 160f

                // Crank pin position
                val crankPinX = centerX + crankRadius * sin(crankRad).toFloat()
                val crankPinY = centerY - crankRadius * cos(crankRad).toFloat()

                // Oil Sump & Splash droplets
                drawOilSumpAndSplash(centerX, centerY, crankPinX, crankPinY, state.rpm)

                // 2. Dual Heavy Flywheels & Fan
                if (state.isFlywheelFanAttached) {
                    drawListerFlywheels(centerX, centerY, state.crankAngleDegrees, state.rpm)
                }

                // Hand Crank Handle on right flywheel hub
                drawHandCrank(centerX + 120f, centerY, state.crankAngleDegrees, state.isHandCrankingActive)

                // 3. Engine Block & Cylinder Liner Cutaway
                drawEngineBlockAndLiner(centerX, centerY)

                // 4. 2:1 Timing Gears & Camshaft Assembly
                drawTimingGearsAndCamshaft(centerX, centerY, state.crankAngleDegrees)

                // 5. Crankshaft, Piston & Connecting Rod Assembly
                val pistonY = centerY - 140f - (crankRadius * cos(crankRad).toFloat() + 
                        kotlin.math.sqrt(conRodLength * conRodLength - (crankRadius * sin(crankRad).toFloat()) * (crankRadius * sin(crankRad).toFloat())))

                // Draw Connecting Rod
                drawConnectingRod(crankPinX, crankPinY, centerX, pistonY + 30f)

                // Draw Crankshaft Center Pin
                drawCircle(color = Color(0xFFD4AF37), radius = 18f, center = Offset(centerX, centerY))
                drawCircle(color = Color(0xFF2C3E50), radius = 8f, center = Offset(centerX, centerY))
                drawCircle(color = Color(0xFFE74C3C), radius = 10f, center = Offset(crankPinX, crankPinY))

                // Draw Piston & Rings
                drawPistonAssembly(centerX, pistonY)

                // 6. Cylinder Head, Pushrods & Rocker Arms Valve Train
                val cylinderHeadY = centerY - 250f
                if (state.isCylinderHeadAttached) {
                    drawPushrodsAndRockerArms(centerX, cylinderHeadY, state.crankAngleDegrees, state.currentPhase, state.isDecompressionLeverRaised)
                    drawCylinderHead(centerX, cylinderHeadY, state.currentPhase, state.isDecompressionLeverRaised)
                    drawDecompressionLever(centerX, cylinderHeadY - 45f, state.isDecompressionLeverRaised)
                }

                // 7. Fuel Injector & Atomized Diesel Spray / Combustion Flame
                if (state.isFuelInjectorAttached) {
                    drawFuelInjector(centerX, cylinderHeadY - 40f)
                    
                    if (state.isEngineRunning && state.currentPhase == EngineFourStrokePhase.POWER && state.crankAngleDegrees % 720f in 340f..420f) {
                        drawDieselSpray(centerX, cylinderHeadY + 25f)
                        drawCombustionFlame(centerX, cylinderHeadY + 45f, state.cylinder1PressureBar)
                    }
                }

                // 8. Mechanical Governor Linkage
                if (state.isGovernorAttached) {
                    drawGovernorLinkage(centerX + 90f, centerY - 40f, state.governorThrottlePercent, state.rpm)
                }

                // 9. Fuel Tank
                if (state.isFuelTankAttached) {
                    drawFuelTank(centerX + 180f, centerY - 150f, state.fuelLevelPercent, state.isFuelValveOpen)
                }

                // 10. Exhaust Pipe & Muffler Smoke Puffs
                if (state.isExhaustAttached) {
                    drawExhaustSilencer(centerX - 180f, centerY - 160f, state.isEngineRunning, state.sootSmokeDensity, state.crankAngleDegrees, state.currentPhase)
                } else if (state.isEngineRunning) {
                    drawOpenExhaustSmoke(centerX - 95f, cylinderHeadY + 15f, state.crankAngleDegrees, state.currentPhase)
                }
            }
        }

        // Overlay Current Stroke & Phase Info Badge
        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp),
            color = Color(0xDD1F242D),
            shape = RoundedCornerShape(8.dp),
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = if (state.language == AppLanguage.AR) state.currentPhase.labelAr else state.currentPhase.labelEn,
                    color = Color(0xFFD4AF37),
                    fontSize = 14.sp,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = if (state.language == AppLanguage.AR) "الدورات: ${state.rpm.toInt()} RPM" else "Engine RPM: ${state.rpm.toInt()}",
                    color = Color.White,
                    fontSize = 12.sp
                )
            }
        }

        // Overlay Real-Time Telemetry Dashboard (RPM, Fuel Consumption Rate, & Torque Output Curves)
        RealtimeTelemetryDashboard(
            state = state,
            onToggleExpanded = onToggleTelemetryExpanded,
            onToggleRpm = onToggleRpm,
            onToggleFuel = onToggleFuel,
            onToggleTorque = onToggleTorque,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(12.dp)
        )
    }
}

private fun DrawScope.drawBasePlate(centerX: Float, centerY: Float) {
    val plateWidth = 400f
    val plateHeight = 38f
    val topX = centerX - plateWidth / 2f
    val topY = centerY + 140f

    // Heavy Cast-Iron Lister Green Base Mounting Flange
    drawRoundRect(
        color = Color(0xFF102B19),
        topLeft = Offset(topX, topY),
        size = Size(plateWidth, plateHeight),
        cornerRadius = CornerRadius(8f, 8f)
    )
    drawRoundRect(
        color = Color(0xFF1B4D2E),
        topLeft = Offset(topX + 4f, topY + 4f),
        size = Size(plateWidth - 8f, plateHeight - 8f),
        cornerRadius = CornerRadius(6f, 6f)
    )

    // Steel Mounting Anchor Bolts with Washers
    val boltOffsets = listOf(-170f, -110f, 110f, 170f)
    for (off in boltOffsets) {
        drawCircle(color = Color(0xFF7F8C8D), radius = 9f, center = Offset(centerX + off, topY + 19f))
        drawCircle(color = Color(0xFFBDC3C7), radius = 6f, center = Offset(centerX + off, topY + 19f))
        drawCircle(color = Color(0xFF2C3E50), radius = 3f, center = Offset(centerX + off, topY + 19f))
    }
}

private fun DrawScope.drawListerFlywheels(centerX: Float, centerY: Float, angle: Float, rpm: Float) {
    val radius = 115f
    // Left Heavy Spoked Flywheel
    drawFlywheelSingle(centerX - 125f, centerY, angle, radius)
    // Right Heavy Spoked Flywheel with Cooling Fan Ribs
    drawFlywheelSingle(centerX + 125f, centerY, angle, radius)
}

private fun DrawScope.drawFlywheelSingle(cx: Float, cy: Float, angle: Float, radius: Float) {
    // Outer Polished Steel Rim Edge
    drawCircle(color = Color(0xFF7F8C8D), radius = radius + 2f, center = Offset(cx, cy))
    drawCircle(color = Color(0xFFBDC3C7), radius = radius, center = Offset(cx, cy))
    // Outer Cast Iron Rim Body (Lister Brunswick Green)
    drawCircle(color = Color(0xFF1B4D2E), radius = radius - 14f, center = Offset(cx, cy))
    // Recessed Inner Hub Web Cavity
    drawCircle(color = Color(0xFF102B19), radius = radius - 26f, center = Offset(cx, cy))
    // Solid Brass Shaft Hub & Keyway
    drawCircle(color = Color(0xFFD4AF37), radius = 30f, center = Offset(cx, cy))
    drawCircle(color = Color(0xFF2C3E50), radius = 14f, center = Offset(cx, cy))

    rotate(degrees = angle, pivot = Offset(cx, cy)) {
        // Heavy Rim Counterweight Lobe (Opposite Crankpin)
        val counterweightPath = Path().apply {
            addArc(
                oval = androidx.compose.ui.geometry.Rect(
                    cx - (radius - 14f),
                    cy - (radius - 14f),
                    cx + (radius - 14f),
                    cy + (radius - 14f)
                ),
                startAngleDegrees = 120f,
                sweepAngleDegrees = 120f
            )
        }
        drawPath(path = counterweightPath, color = Color(0xFF163E25), style = Stroke(width = 22f))

        // 6 Curved Teardrop Spokes
        val numSpokes = 6
        for (i in 0 until numSpokes) {
            val spokeAngle = Math.toRadians((i * (360.0 / numSpokes)))
            val startX = cx + 28f * cos(spokeAngle).toFloat()
            val startY = cy + 28f * sin(spokeAngle).toFloat()
            val endX = cx + (radius - 26f) * cos(spokeAngle).toFloat()
            val endY = cy + (radius - 26f) * sin(spokeAngle).toFloat()
            
            drawLine(
                color = Color(0xFF276A42),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 14f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color(0xFFBDC3C7),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 3f,
                cap = StrokeCap.Round
            )
        }
    }
}

private fun DrawScope.drawEngineBlockAndLiner(centerX: Float, centerY: Float) {
    val linerWidth = 136f
    val linerHeight = 225f
    val left = centerX - linerWidth / 2f
    val top = centerY - 215f

    // 1. Outer Heavy Cast-Iron Engine Block (Lister Brunswick Green)
    val outerBlockWidth = linerWidth + 56f
    val outerBlockLeft = centerX - outerBlockWidth / 2f
    
    // Main Block Casing
    drawRoundRect(
        color = Color(0xFF1B4D2E),
        topLeft = Offset(outerBlockLeft, top - 10f),
        size = Size(outerBlockWidth, linerHeight + 20f),
        cornerRadius = CornerRadius(10f, 10f)
    )

    // Horizontal Engine Cooling Fins on Exterior Barrel (5 fins on left & right)
    for (i in 0..4) {
        val finY = top + 20f + (i * 40f)
        // Left Fin
        drawRoundRect(
            color = Color(0xFF276A42),
            topLeft = Offset(outerBlockLeft - 12f, finY),
            size = Size(18f, 12f),
            cornerRadius = CornerRadius(3f, 3f)
        )
        // Right Fin
        drawRoundRect(
            color = Color(0xFF276A42),
            topLeft = Offset(outerBlockLeft + outerBlockWidth - 6f, finY),
            size = Size(18f, 12f),
            cornerRadius = CornerRadius(3f, 3f)
        )
    }

    // 2. Water Jacket Coolant Cavity (Liquid Blue Coolant Space)
    drawRect(
        color = Color(0x662980B9),
        topLeft = Offset(left - 18f, top + 15f),
        size = Size(linerWidth + 36f, linerHeight - 45f)
    )

    // 3. Removable Wet Cylinder Liner Sleeve (Hardened Alloy Steel)
    drawRect(
        color = Color(0xFF2C3E50),
        topLeft = Offset(left - 8f, top),
        size = Size(linerWidth + 16f, linerHeight)
    )
    drawRect(
        color = Color(0xFF4A5568),
        topLeft = Offset(left, top),
        size = Size(linerWidth, linerHeight)
    )

    // Cross-Hatch Honing Texture Lines inside Cylinder Wall
    for (y in top.toInt()..(top + linerHeight).toInt() step 20) {
        drawLine(
            color = Color(0x33FFFFFF),
            start = Offset(left, y.toFloat()),
            end = Offset(left + linerWidth, y + 15f),
            strokeWidth = 1.2f
        )
        drawLine(
            color = Color(0x33FFFFFF),
            start = Offset(left + linerWidth, y.toFloat()),
            end = Offset(left, y + 15f),
            strokeWidth = 1.2f
        )
    }
}

private fun DrawScope.drawPistonAssembly(centerX: Float, pistonY: Float) {
    val pistonWidth = 130f
    val pistonHeight = 94f
    val left = centerX - pistonWidth / 2f

    // Piston Aluminum Alloy Body
    drawRoundRect(
        color = Color(0xFF7F8C8D),
        topLeft = Offset(left, pistonY),
        size = Size(pistonWidth, pistonHeight),
        cornerRadius = CornerRadius(6f, 6f)
    )
    drawRoundRect(
        color = Color(0xFFBDC3C7),
        topLeft = Offset(left + 4f, pistonY + 4f),
        size = Size(pistonWidth - 8f, pistonHeight - 8f),
        cornerRadius = CornerRadius(4f, 4f)
    )

    // Piston Crown Direct-Injection Toroidal Bowl (Lister Bowl Cavity in Piston Top)
    drawArc(
        color = Color(0xFF2C3E50),
        startAngle = 0f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(centerX - 30f, pistonY),
        size = Size(60f, 22f)
    )

    // 3 Compression Rings + 1 Oil Scraper Ring at Bottom Skirt
    val ringPositions = listOf(pistonY + 12f, pistonY + 24f, pistonY + 36f, pistonY + 76f)
    for ((idx, ry) in ringPositions.withIndex()) {
        val ringColor = if (idx == 3) Color(0xFFD4AF37) else Color(0xFF2C3E50) // Gold oil scraper ring
        drawLine(
            color = ringColor,
            start = Offset(left - 3f, ry),
            end = Offset(left + pistonWidth + 3f, ry),
            strokeWidth = 4f
        )
    }

    // Gudgeon Pin / Wrist Pin Hole & Bronze Bushing Center
    drawCircle(color = Color(0xFFD4AF37), radius = 16f, center = Offset(centerX, pistonY + 55f))
    drawCircle(color = Color(0xFF2C3E50), radius = 10f, center = Offset(centerX, pistonY + 55f))
}

private fun DrawScope.drawConnectingRod(startX: Float, startY: Float, endX: Float, endY: Float) {
    // Forged H-Beam Connecting Rod Outer Body
    drawLine(
        color = Color(0xFF102B19),
        start = Offset(startX, startY),
        end = Offset(endX, endY),
        strokeWidth = 22f,
        cap = StrokeCap.Round
    )
    // Forged Steel Body Metallic Fill
    drawLine(
        color = Color(0xFF7F8C8D),
        start = Offset(startX, startY),
        end = Offset(endX, endY),
        strokeWidth = 16f,
        cap = StrokeCap.Round
    )
    // H-Beam Recessed Rib Center Accent
    drawLine(
        color = Color(0xFF2C3E50),
        start = Offset(startX, startY),
        end = Offset(endX, endY),
        strokeWidth = 6f,
        cap = StrokeCap.Round
    )

    // Big-End Bearing Cap Bolts & Oil Dipper Spoon
    drawCircle(color = Color(0xFFD4AF37), radius = 14f, center = Offset(startX, startY))
    // Oil Dipper Spoon extending downward into sump oil bath
    drawLine(
        color = Color(0xFFBDC3C7),
        start = Offset(startX, startY),
        end = Offset(startX, startY + 22f),
        strokeWidth = 5f,
        cap = StrokeCap.Round
    )
}

private fun DrawScope.drawOilSumpAndSplash(centerX: Float, centerY: Float, crankPinX: Float, crankPinY: Float, rpm: Float) {
    val sumpWidth = 190f
    val sumpHeight = 45f
    val left = centerX - sumpWidth / 2f
    val top = centerY + 95f

    // Amber Engine Oil Pool in Crankcase Sump
    drawRoundRect(
        color = Color(0xB3E67E22),
        topLeft = Offset(left, top),
        size = Size(sumpWidth, sumpHeight),
        cornerRadius = CornerRadius(10f, 10f)
    )

    // Dipstick Tube & Brass Cap (Right Side of Crankcase)
    drawLine(
        color = Color(0xFF7F8C8D),
        start = Offset(centerX + 85f, top + 10f),
        end = Offset(centerX + 115f, top - 45f),
        strokeWidth = 6f
    )
    drawCircle(color = Color(0xFFD4AF37), radius = 8f, center = Offset(centerX + 115f, top - 45f))

    // Dynamic Oil Splash Droplets when big-end bearing passes through bottom oil bath
    if (rpm > 20f && crankPinY > centerY + 10f) {
        val numDroplets = 6
        for (i in 0 until numDroplets) {
            val angle = (crankPinX + i * 25f) % 360f
            val dropX = crankPinX + (i - 3) * 14f
            val dropY = crankPinY - 12f - (i * 7f)
            drawCircle(color = Color(0xFFF39C12), radius = 3.5f, center = Offset(dropX, dropY))
        }
    }
}

private fun DrawScope.drawTimingGearsAndCamshaft(centerX: Float, centerY: Float, crankAngle: Float) {
    val gearCenterX = centerX + 68f
    val gearCenterY = centerY + 25f

    // 1. Small Crankshaft Pinion Gear (24 Teeth)
    drawCircle(color = Color(0xFF7F8C8D), radius = 18f, center = Offset(centerX, centerY))
    rotate(degrees = crankAngle, pivot = Offset(centerX, centerY)) {
        for (i in 0 until 8) {
            val toothAngle = Math.toRadians((i * 45.0))
            val tx = centerX + 18f * cos(toothAngle).toFloat()
            val ty = centerY + 18f * sin(toothAngle).toFloat()
            drawCircle(color = Color(0xFF95A5A6), radius = 3f, center = Offset(tx, ty))
        }
    }

    // 2. Large 2:1 Camshaft Timing Gear (48 Teeth - Half speed)
    val camAngle = crankAngle / 2f
    drawCircle(color = Color(0xFFD4AF37), radius = 34f, center = Offset(gearCenterX, gearCenterY))
    drawCircle(color = Color(0xFF2C3E50), radius = 12f, center = Offset(gearCenterX, gearCenterY))

    rotate(degrees = camAngle, pivot = Offset(gearCenterX, gearCenterY)) {
        for (i in 0 until 12) {
            val toothAngle = Math.toRadians((i * 30.0))
            val tx = gearCenterX + 34f * cos(toothAngle).toFloat()
            val ty = gearCenterY + 34f * sin(toothAngle).toFloat()
            drawCircle(color = Color(0xFFBDC3C7), radius = 3.5f, center = Offset(tx, ty))
        }
        // Cam Lobe Profile
        drawCircle(color = Color(0xFFE74C3C), radius = 7f, center = Offset(gearCenterX + 16f, gearCenterY))
    }
}

private fun DrawScope.drawPushrodsAndRockerArms(
    centerX: Float,
    headY: Float,
    crankAngle: Float,
    phase: EngineFourStrokePhase,
    isDecompressed: Boolean
) {
    val camAngleRad = Math.toRadians((crankAngle / 2f).toDouble())
    val intakePushrodLift = if (phase == EngineFourStrokePhase.INTAKE) (sin(camAngleRad).toFloat() * 12f).coerceAtLeast(0f) else 0f
    val exhaustPushrodLift = if (phase == EngineFourStrokePhase.EXHAUST || isDecompressed) {
        if (isDecompressed) 10f else (sin(camAngleRad).toFloat() * 12f).coerceAtLeast(0f)
    } else 0f

    // Solid Steel Pushrods (Left: Intake, Right: Exhaust)
    val pushrodLeftX = centerX - 45f
    val pushrodRightX = centerX + 45f
    val pushrodBottomY = headY + 110f
    val pushrodTopIntakeY = headY - 15f - intakePushrodLift
    val pushrodTopExhaustY = headY - 15f - exhaustPushrodLift

    // Intake Pushrod
    drawLine(
        color = Color(0xFFBDC3C7),
        start = Offset(pushrodLeftX, pushrodBottomY),
        end = Offset(pushrodLeftX, pushrodTopIntakeY),
        strokeWidth = 5f
    )

    // Exhaust Pushrod
    drawLine(
        color = Color(0xFFBDC3C7),
        start = Offset(pushrodRightX, pushrodBottomY),
        end = Offset(pushrodRightX, pushrodTopExhaustY),
        strokeWidth = 5f
    )

    // Rocker Shaft Pivot Center
    val rockerShaftY = headY - 32f
    drawCircle(color = Color(0xFFD4AF37), radius = 8f, center = Offset(centerX - 35f, rockerShaftY))
    drawCircle(color = Color(0xFFD4AF37), radius = 8f, center = Offset(centerX + 35f, rockerShaftY))

    // Pivoting Forged Steel Rocker Arms
    // Intake Rocker Arm (Tilts when intake pushrod lifts)
    drawLine(
        color = Color(0xFF95A5A6),
        start = Offset(pushrodLeftX, pushrodTopIntakeY),
        end = Offset(centerX - 35f + 18f, rockerShaftY + intakePushrodLift * 0.8f),
        strokeWidth = 7f,
        cap = StrokeCap.Round
    )

    // Exhaust Rocker Arm
    drawLine(
        color = Color(0xFF95A5A6),
        start = Offset(pushrodRightX, pushrodTopExhaustY),
        end = Offset(centerX + 35f - 18f, rockerShaftY + exhaustPushrodLift * 0.8f),
        strokeWidth = 7f,
        cap = StrokeCap.Round
    )
}

private fun DrawScope.drawDecompressionLever(centerX: Float, leverY: Float, isRaised: Boolean) {
    val lx = centerX + 50f
    // Base Pivot Hub
    drawCircle(color = Color(0xFF7F8C8D), radius = 7f, center = Offset(lx, leverY))

    // Lever Handle (Gold Brass Lever flipped UP when decompressed, DOWN when running)
    val handleAngle = if (isRaised) -70f else 15f
    rotate(degrees = handleAngle, pivot = Offset(lx, leverY)) {
        drawLine(
            color = Color(0xFFD4AF37),
            start = Offset(lx, leverY),
            end = Offset(lx + 32f, leverY),
            strokeWidth = 6f,
            cap = StrokeCap.Round
        )
        drawCircle(color = Color(0xFFE74C3C), radius = 6f, center = Offset(lx + 32f, leverY))
    }
}

private fun DrawScope.drawHandCrank(hubX: Float, hubY: Float, angle: Float, isActive: Boolean) {
    if (!isActive) return
    rotate(degrees = angle, pivot = Offset(hubX, hubY)) {
        // Crank Arm
        drawLine(
            color = Color(0xFF7F8C8D),
            start = Offset(hubX, hubY),
            end = Offset(hubX + 65f, hubY),
            strokeWidth = 9f,
            cap = StrokeCap.Round
        )
        // Revolving Grip Handle
        drawCircle(color = Color(0xFF8D6E63), radius = 9f, center = Offset(hubX + 65f, hubY))
    }
}

private fun DrawScope.drawCylinderHead(centerX: Float, headY: Float, phase: EngineFourStrokePhase, isDecompressed: Boolean) {
    val width = 170f
    val height = 65f
    val left = centerX - width / 2f

    // Cylinder Head Block
    drawRoundRect(
        color = Color(0xFF34495E),
        topLeft = Offset(left, headY),
        size = Size(width, height),
        cornerRadius = CornerRadius(8f, 8f)
    )

    // Intake & Exhaust Valves
    val intakeValveOpen = (phase == EngineFourStrokePhase.INTAKE)
    val exhaustValveOpen = (phase == EngineFourStrokePhase.EXHAUST || isDecompressed)

    val intakeOffset = if (intakeValveOpen) 15f else 0f
    val exhaustOffset = if (exhaustValveOpen) (if (isDecompressed) 10f else 15f) else 0f

    // Valve Springs (Coils around valve stems)
    drawValveSpring(centerX - 35f, headY - 12f, intakeOffset)
    drawValveSpring(centerX + 35f, headY - 12f, exhaustOffset)

    // Intake Valve Stem & Poppet Head
    drawLine(
        color = Color(0xFF2ECC71),
        start = Offset(centerX - 35f, headY - 15f),
        end = Offset(centerX - 35f, headY + 45f + intakeOffset),
        strokeWidth = 6f
    )
    drawCircle(color = Color(0xFF2ECC71), radius = 10f, center = Offset(centerX - 35f, headY + 45f + intakeOffset))

    // Exhaust Valve Stem & Poppet Head
    drawLine(
        color = Color(0xFFE74C3C),
        start = Offset(centerX + 35f, headY - 15f),
        end = Offset(centerX + 35f, headY + 45f + exhaustOffset),
        strokeWidth = 6f
    )
    drawCircle(color = Color(0xFFE74C3C), radius = 10f, center = Offset(centerX + 35f, headY + 45f + exhaustOffset))
}

private fun DrawScope.drawValveSpring(sx: Float, sy: Float, offset: Float) {
    val springHeight = 22f - offset * 0.4f
    for (i in 0..4) {
        val y = sy + (i * (springHeight / 4f))
        drawLine(
            color = Color(0xFFBDC3C7),
            start = Offset(sx - 8f, y),
            end = Offset(sx + 8f, y + 2f),
            strokeWidth = 3f
        )
    }
}

private fun DrawScope.drawFuelInjector(centerX: Float, injectorY: Float) {
    // Injector Body
    drawRect(
        color = Color(0xFFD4AF37),
        topLeft = Offset(centerX - 10f, injectorY),
        size = Size(20f, 45f)
    )
    // High pressure fuel feed pipe
    drawLine(
        color = Color(0xFFF39C12),
        start = Offset(centerX + 10f, injectorY + 10f),
        end = Offset(centerX + 120f, injectorY - 20f),
        strokeWidth = 5f
    )
}

private fun DrawScope.drawDieselSpray(centerX: Float, sprayY: Float) {
    // Cone spray particles
    val path = Path().apply {
        moveTo(centerX, sprayY)
        lineTo(centerX - 30f, sprayY + 40f)
        lineTo(centerX + 30f, sprayY + 40f)
        close()
    }
    drawPath(path = path, color = Color(0xBBF1C40F))
}

private fun DrawScope.drawCombustionFlame(centerX: Float, flameY: Float, pressureBar: Float) {
    val intensityRadius = (25f + (pressureBar / 60f) * 20f).coerceIn(20f, 50f)
    drawCircle(color = Color(0xFFFF5722), radius = intensityRadius, center = Offset(centerX, flameY))
    drawCircle(color = Color(0xFFFFEB3B), radius = intensityRadius * 0.6f, center = Offset(centerX, flameY))
}

private fun DrawScope.drawGovernorLinkage(gx: Float, gy: Float, throttle: Float, rpm: Float) {
    // Flyball governor housing
    drawCircle(color = Color(0xFF7F8C8D), radius = 22f, center = Offset(gx, gy))

    // Centrifugal Flyballs
    val spread = 12f + (rpm / 600f) * 16f
    drawCircle(color = Color(0xFFD4AF37), radius = 8f, center = Offset(gx - spread, gy - 12f))
    drawCircle(color = Color(0xFFD4AF37), radius = 8f, center = Offset(gx + spread, gy + 12f))

    // Control Linkage arm to throttle rack
    drawLine(
        color = Color(0xFFBDC3C7),
        start = Offset(gx, gy),
        end = Offset(gx - 70f, gy - (throttle / 100f) * 25f),
        strokeWidth = 4f
    )
}

private fun DrawScope.drawFuelTank(tx: Float, ty: Float, fuelLevel: Float, isValveOpen: Boolean) {
    val width = 100f
    val height = 110f

    // Outer Metallic Tank Body
    drawRoundRect(
        color = Color(0xFF2C3E50),
        topLeft = Offset(tx, ty),
        size = Size(width, height),
        cornerRadius = CornerRadius(10f, 10f)
    )

    // Diesel Fuel Liquid Fill Gauge
    val fillHeight = (height - 20f) * (fuelLevel / 100f)
    drawRect(
        color = Color(0xCCF39C12),
        topLeft = Offset(tx + 10f, ty + height - 10f - fillHeight),
        size = Size(width - 20f, fillHeight)
    )

    // Fuel Tap Switch
    drawCircle(
        color = if (isValveOpen) Color(0xFF2ECC71) else Color(0xFFE74C3C),
        radius = 10f,
        center = Offset(tx + 20f, ty + height + 15f)
    )
}

private fun DrawScope.drawExhaustSilencer(
    ex: Float,
    ey: Float,
    isRunning: Boolean,
    sootDensity: Float,
    angle: Float,
    phase: EngineFourStrokePhase
) {
    // Exhaust Manifold Pipe & Silencer Drum
    drawRoundRect(
        color = Color(0xFF34495E),
        topLeft = Offset(ex, ey),
        size = Size(60f, 120f),
        cornerRadius = CornerRadius(8f, 8f)
    )

    // Pipe connection to cylinder head
    drawLine(
        color = Color(0xFF7F8C8D),
        start = Offset(ex + 60f, ey + 70f),
        end = Offset(ex + 120f, ey + 70f),
        strokeWidth = 14f
    )

    if (isRunning) {
        val isExhaustStroke = (phase == EngineFourStrokePhase.EXHAUST)
        val smokeAlpha = (sootDensity * 220).toInt().coerceIn(60, 240)
        val puffSize = if (isExhaustStroke) 32f else 20f
        
        drawCircle(color = Color(90, 90, 90, smokeAlpha), radius = puffSize, center = Offset(ex + 30f, ey - 30f))
        drawCircle(color = Color(120, 120, 120, (smokeAlpha * 0.7f).toInt()), radius = puffSize * 1.4f, center = Offset(ex + 20f, ey - 75f))
    }
}

private fun DrawScope.drawOpenExhaustSmoke(pipeX: Float, pipeY: Float, angle: Float, phase: EngineFourStrokePhase) {
    val isExhaustStroke = (phase == EngineFourStrokePhase.EXHAUST)
    val puffSize = if (isExhaustStroke) 38f else 22f
    drawCircle(color = Color(40, 40, 40, 220), radius = puffSize, center = Offset(pipeX - 40f, pipeY - 20f))
    drawCircle(color = Color(60, 60, 60, 180), radius = puffSize * 1.5f, center = Offset(pipeX - 70f, pipeY - 50f))
}
