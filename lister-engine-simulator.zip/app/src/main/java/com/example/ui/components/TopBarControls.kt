package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.CylinderConfig
import com.example.model.EngineState
import com.example.model.SimulatorTab
import com.example.ui.theme.ImmersiveBlueContainer
import com.example.ui.theme.ImmersiveBluePrimary
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.IndustrialCardSurfaceVariant
import com.example.ui.theme.IndustrialDarkBackground
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted

@Composable
fun TopBarControls(
    state: EngineState,
    onStartCrank: () -> Unit,
    onStopEngine: () -> Unit,
    onToggleDecompression: () -> Unit,
    onToggleFuelValve: () -> Unit,
    onRefillFuel: () -> Unit,
    onSelectCylinderConfig: (CylinderConfig) -> Unit,
    onSelectTab: (SimulatorTab) -> Unit,
    onToggleLanguage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val crankRotation by rememberInfiniteTransition(label = "crank").animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(400, easing = LinearEasing)),
        label = "crank_spin"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(IndustrialCardSurfaceVariant)
            .border(width = 1.dp, color = ImmersiveBorder)
            .padding(top = 10.dp, start = 14.dp, end = 14.dp, bottom = 4.dp)
    ) {
        // App Title Bar & Status Pill
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Immersive UI Logo Badge
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ImmersiveBlueContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "L",
                        color = Color(0xFF00315C),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = if (state.language == AppLanguage.AR) "محاكي محرك ليستر CS" else "Lister CS Simulator",
                        color = Color(0xFFE1E2E5),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = if (state.language == AppLanguage.AR) "طراز CS 6/1 - محرك ديزل بطيء الدوران" else "MODEL: CS-1 (SLOW-SPEED DIESEL)",
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // System Status Pill Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF2D3135))
                        .border(1.dp, Color(0xFF3E4246), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (state.isEngineRunning) "SYSTEM: ACTIVE" else "SYSTEM: STANDBY",
                        color = if (state.isEngineRunning) Color(0xFF00E676) else TextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Language Toggle Button
                IconButton(
                    onClick = onToggleLanguage,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("language_toggle_button")
                ) {
                    Icon(
                        Icons.Default.Language,
                        contentDescription = "Language",
                        tint = ImmersiveBlueContainer,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Cylinder Config & Engine Control Buttons Deck
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Hand Crank Button (Immersive UI Primary Blue Action)
            Button(
                onClick = onStartCrank,
                enabled = !state.isEngineRunning && !state.isHandCrankingActive,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ImmersiveBluePrimary,
                    contentColor = ImmersiveBlueContainer,
                    disabledContainerColor = Color(0xFF2D3135),
                    disabledContentColor = TextDim
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1.4f)
                    .height(44.dp)
                    .testTag("hand_crank_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Hand Crank",
                    tint = if (state.isEngineRunning) TextDim else ImmersiveBlueContainer,
                    modifier = Modifier
                        .size(16.dp)
                        .rotate(if (state.isHandCrankingActive) crankRotation else 0f)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (state.isHandCrankingActive)
                        (if (state.language == AppLanguage.AR) "جاري التدوير..." else "CRANKING...")
                    else (if (state.language == AppLanguage.AR) "تدوير بالهندل" else "START CRANK"),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            // Decompression Lever (Immersive Amber Accent)
            OutlinedButton(
                onClick = onToggleDecompression,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (state.isDecompressionLeverRaised) Color(0xFFFF9800) else Color(0xFF15171A)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF323539)),
                modifier = Modifier
                    .weight(1.1f)
                    .height(44.dp)
                    .testTag("decompression_lever_button")
            ) {
                Text(
                    text = if (state.language == AppLanguage.AR) "رفع الضغط" else "DECOMPRESS",
                    color = if (state.isDecompressionLeverRaised) Color.Black else Color(0xFFFF9800),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Fuel Valve Toggle
            OutlinedButton(
                onClick = onToggleFuelValve,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color(0xFF15171A)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (state.isFuelValveOpen) Color(0xFF00E676) else Color(0xFFFF5252)),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("fuel_valve_button")
            ) {
                Text(
                    text = if (state.isFuelValveOpen)
                        (if (state.language == AppLanguage.AR) "محبس: مفتوح" else "FUEL: ON")
                    else (if (state.language == AppLanguage.AR) "محبس: مغلق" else "FUEL: OFF"),
                    color = if (state.isFuelValveOpen) Color(0xFF00E676) else Color(0xFFFF5252),
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            // Stop Button (Red Warning Container)
            if (state.isEngineRunning) {
                Button(
                    onClick = onStopEngine,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF3E0007),
                        contentColor = Color(0xFFFFB4AB)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF93000A)),
                    modifier = Modifier
                        .weight(0.9f)
                        .height(44.dp)
                        .testTag("emergency_stop_button")
                ) {
                    Text(
                        text = if (state.language == AppLanguage.AR) "إيقاف" else "STOP",
                        color = Color(0xFFFFB4AB),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Navigation Mode Tabs
        TabRow(
            selectedTabIndex = state.activeTab.ordinal,
            containerColor = IndustrialDarkBackground,
            contentColor = ImmersiveBlueContainer,
            divider = {}
        ) {
            SimulatorTab.values().forEach { tab ->
                Tab(
                    selected = state.activeTab == tab,
                    onClick = { onSelectTab(tab) },
                    text = {
                        Text(
                            text = if (state.language == AppLanguage.AR) tab.titleAr else tab.titleEn,
                            fontSize = 10.sp,
                            fontWeight = if (state.activeTab == tab) FontWeight.Bold else FontWeight.Normal,
                            color = if (state.activeTab == tab) ImmersiveBlueContainer else TextMuted
                        )
                    },
                    modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
                )
            }
        }
    }
}

