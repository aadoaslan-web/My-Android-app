package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.EngineState
import com.example.ui.theme.ImmersiveBlueContainer
import com.example.ui.theme.ImmersiveBluePrimary
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.IndustrialCardSurface
import com.example.ui.theme.IndustrialCardSurfaceVariant
import com.example.ui.theme.IndustrialDarkBackground
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted

@Composable
fun ControlPanel(
    state: EngineState,
    onLoadChange: (Float) -> Unit,
    onToggleBreaker: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(IndustrialDarkBackground)
            .padding(16.dp)
            .verticalScroll(scrollState)
            .testTag("generator_control_panel")
    ) {
        // Header Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (state.language == AppLanguage.AR) "لوحة التحكم الكهربائية للمولد" else "Generator Electrical Control Panel",
                    color = Color(0xFFE1E2E5),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (state.language == AppLanguage.AR) "دينامو أحادي الطور 220V / 50Hz" else "SINGLE-PHASE ALTERNATOR 220V / 50HZ",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Power Output LED Status Indicator
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(if (state.outputVoltage > 50f) Color(0xFF00E676) else Color(0xFFFF5252))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (state.outputVoltage > 50f) "LIVE" else "OFF",
                    color = if (state.outputVoltage > 50f) Color(0xFF00E676) else Color(0xFFFF5252),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Grid of Analog Needles Gauges
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            AnalogGauge(
                value = state.outputVoltage,
                minValue = 0f,
                maxValue = 300f,
                title = if (state.language == AppLanguage.AR) "الجهد (الفولت)" else "Voltmeter",
                unit = "V",
                warningThreshold = 250f,
                testTag = "voltmeter_gauge"
            )

            AnalogGauge(
                value = state.outputAmperage,
                minValue = 0f,
                maxValue = 40f,
                title = if (state.language == AppLanguage.AR) "التيار (الأمبير)" else "Ammeter",
                unit = "A",
                warningThreshold = 30f,
                testTag = "ammeter_gauge"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            AnalogGauge(
                value = state.rpm,
                minValue = 0f,
                maxValue = 1000f,
                title = if (state.language == AppLanguage.AR) "سرعة الدوران" else "Tachometer",
                unit = "RPM",
                warningThreshold = 800f,
                testTag = "rpm_gauge"
            )

            AnalogGauge(
                value = state.outputFrequencyHz,
                minValue = 0f,
                maxValue = 70f,
                title = if (state.language == AppLanguage.AR) "التردد" else "Frequency",
                unit = "Hz",
                warningThreshold = 62f,
                testTag = "frequency_gauge"
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Main Circuit Breaker Switch Card
        Card(
            colors = CardDefaults.cardColors(containerColor = IndustrialCardSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (state.language == AppLanguage.AR) "القاطع الرئيسي (Main Circuit Breaker)" else "Main Circuit Breaker",
                        color = Color(0xFFE1E2E5),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = if (state.isCircuitBreakerClosed)
                            (if (state.language == AppLanguage.AR) "مغلق (متصل بالحمل)" else "CLOSED (CONNECTED TO LOAD)")
                        else (if (state.language == AppLanguage.AR) "مفتوح (مفصول)" else "OPEN (DISCONNECTED)"),
                        color = if (state.isCircuitBreakerClosed) Color(0xFF00E676) else Color(0xFFFF5252),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Switch(
                    checked = state.isCircuitBreakerClosed,
                    onCheckedChange = { onToggleBreaker() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF00E676),
                        checkedTrackColor = Color(0xFF00315C),
                        uncheckedThumbColor = Color(0xFFFF5252),
                        uncheckedTrackColor = Color(0xFF3E0007)
                    ),
                    modifier = Modifier.testTag("circuit_breaker_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Electrical Load Control Slider Card
        Card(
            colors = CardDefaults.cardColors(containerColor = IndustrialCardSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (state.language == AppLanguage.AR) "تحكم الحمل الكهربائي" else "Mechanical Governor & Load",
                        color = TextMuted,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "${state.electricalLoadWatts.toInt()} W",
                        color = Color(0xFFE1E2E5),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Slider(
                    value = state.electricalLoadWatts,
                    onValueChange = { onLoadChange(it) },
                    valueRange = 0f..5000f,
                    colors = SliderDefaults.colors(
                        thumbColor = ImmersiveBlueContainer,
                        activeTrackColor = ImmersiveBluePrimary,
                        inactiveTrackColor = Color(0xFF2D3135)
                    ),
                    modifier = Modifier.testTag("load_slider")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Quick Load Preset Buttons
                Text(
                    text = if (state.language == AppLanguage.AR) "أحمال جاهزة:" else "LOAD PRESETS:",
                    color = TextDim,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LoadPresetChip(
                        label = if (state.language == AppLanguage.AR) "إضاءة (500W)" else "Lighting",
                        watts = 500f,
                        icon = Icons.Default.Lightbulb,
                        onClick = { onLoadChange(500f) }
                    )
                    LoadPresetChip(
                        label = if (state.language == AppLanguage.AR) "مضخة ماء (1.5kW)" else "Water Pump",
                        watts = 1500f,
                        icon = Icons.Default.WaterDrop,
                        onClick = { onLoadChange(1500f) }
                    )
                    LoadPresetChip(
                        label = if (state.language == AppLanguage.AR) "طاحونة (3.5kW)" else "Grain Mill",
                        watts = 3500f,
                        icon = Icons.Default.Work,
                        onClick = { onLoadChange(3500f) }
                    )
                }
            }
        }
    }
}

@Composable
private fun RowScope.LoadPresetChip(
    label: String,
    watts: Float,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.weight(1f),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color(0xFF1A1C1E)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        contentPadding = PaddingValues(6.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = label, tint = ImmersiveBlueContainer, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = label, fontSize = 9.sp, color = Color(0xFFE1E2E5))
        }
    }
}

