package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IndustrialDarkBackground = Color(0xFF0F1113)
val IndustrialCardSurface = Color(0xFF15171A)
val IndustrialCardSurfaceVariant = Color(0xFF1A1C1E)
val IndustrialContainerDark = Color(0xFF2D3135)

val ImmersiveBorder = Color(0xFF323539)
val ImmersiveBorderLight = Color(0xFF3E4246)

val ImmersiveBluePrimary = Color(0xFF004A77)
val ImmersiveBlueContainer = Color(0xFFD1E4FF)

val BrassGold = Color(0xFFD4AF37)
val IndustrialCopper = Color(0xFFB87333)
val HeavyIronGray = Color(0xFF2D3135)
val LightSteelHeader = Color(0xFFE1E2E5)

val MeterNeedleRed = Color(0xFFFF5252)
val DieselYellow = Color(0xFFFF9800)
val DieselGreen = Color(0xFF00E676)
val IndustrialWarning = Color(0xFFFF9800)
val IndustrialCyan = Color(0xFF00E676)
val TextMuted = Color(0xFFA8ADBD)
val TextDim = Color(0xFF5F6368)


