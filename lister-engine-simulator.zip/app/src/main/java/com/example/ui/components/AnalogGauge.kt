package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.IndustrialCardSurface
import com.example.ui.theme.IndustrialCardSurfaceVariant
import com.example.ui.theme.MeterNeedleRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AnalogGauge(
    value: Float,
    minValue: Float = 0f,
    maxValue: Float = 300f,
    title: String,
    unit: String,
    warningThreshold: Float? = null,
    testTag: String = "analog_gauge",
    modifier: Modifier = Modifier
) {
    val animatedValue by animateFloatAsState(
        targetValue = value.coerceIn(minValue, maxValue),
        animationSpec = spring(stiffness = 180f, dampingRatio = 0.75f),
        label = "gauge_needle_anim"
    )

    Box(
        modifier = modifier
            .size(165.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(IndustrialCardSurfaceVariant)
            .border(1.dp, ImmersiveBorder, RoundedCornerShape(16.dp))
            .padding(6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = size.width / 2f - 12f

            // Inner Face Dial
            drawCircle(
                color = Color(0xFF15171A),
                radius = radius - 2f,
                center = Offset(cx, cy)
            )

            // Outer ring accent
            drawCircle(
                color = Color(0xFF323539),
                radius = radius - 2f,
                center = Offset(cx, cy),
                style = Stroke(width = 1.5f)
            )

            // Arc scale (225 degrees total arc: 135° to 405°)
            val startAngle = 135f
            val totalSweep = 270f

            drawArc(
                color = Color(0xFF323539),
                startAngle = startAngle,
                sweepAngle = totalSweep,
                useCenter = false,
                topLeft = Offset(cx - radius + 16f, cy - radius + 16f),
                size = Size((radius - 16f) * 2f, (radius - 16f) * 2f),
                style = Stroke(width = 3f, cap = StrokeCap.Round)
            )

            // Warning Zone Arc
            if (warningThreshold != null) {
                val warnRatio = (warningThreshold - minValue) / (maxValue - minValue)
                val warnStart = startAngle + totalSweep * warnRatio
                val warnSweep = totalSweep * (1f - warnRatio)
                drawArc(
                    color = MeterNeedleRed,
                    startAngle = warnStart,
                    sweepAngle = warnSweep,
                    useCenter = false,
                    topLeft = Offset(cx - radius + 16f, cy - radius + 16f),
                    size = Size((radius - 16f) * 2f, (radius - 16f) * 2f),
                    style = Stroke(width = 4f, cap = StrokeCap.Round)
                )
            }

            // Ticks
            val numTicks = 10
            for (i in 0..numTicks) {
                val tickRatio = i.toFloat() / numTicks
                val angleDeg = startAngle + tickRatio * totalSweep
                val angleRad = Math.toRadians(angleDeg.toDouble())

                val tickInnerR = radius - 24f
                val tickOuterR = radius - 16f

                val startX = cx + tickInnerR * cos(angleRad).toFloat()
                val startY = cy + tickInnerR * sin(angleRad).toFloat()
                val endX = cx + tickOuterR * cos(angleRad).toFloat()
                val endY = cy + tickOuterR * sin(angleRad).toFloat()

                drawLine(
                    color = Color(0xFFA8ADBD),
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = if (i % 2 == 0) 2.5f else 1f
                )
            }

            // Calculate Needle Angle
            val normalizedRatio = (animatedValue - minValue) / (maxValue - minValue)
            val needleAngleDeg = startAngle + normalizedRatio * totalSweep

            // Needle Pointer (Immersive Red Needle)
            rotate(degrees = needleAngleDeg, pivot = Offset(cx, cy)) {
                drawLine(
                    color = MeterNeedleRed,
                    start = Offset(cx, cy),
                    end = Offset(cx + radius - 22f, cy),
                    strokeWidth = 3.5f,
                    cap = StrokeCap.Round
                )
            }

            // Center Pin
            drawCircle(color = Color(0xFFE1E2E5), radius = 6f, center = Offset(cx, cy))
            drawCircle(color = Color(0xFF0F1113), radius = 3f, center = Offset(cx, cy))
        }

        // Title & Value Display Text
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 40.dp)
        ) {
            Text(
                text = title.uppercase(),
                color = TextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "${animatedValue.toInt()}",
                    color = Color(0xFFE1E2E5),
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = unit,
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

