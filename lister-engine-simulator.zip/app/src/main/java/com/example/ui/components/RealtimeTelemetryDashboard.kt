package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.EngineState
import com.example.model.TelemetryDataPoint
import com.example.ui.theme.ImmersiveBlueContainer
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.IndustrialCardSurface
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted

// Theme curve colors matching high-contrast telemetry palette
private val ColorRpmCurve = Color(0xFF00E5FF)       // Vibrant Cyan
private val ColorFuelCurve = Color(0xFFFFB300)      // Warm Amber
private val ColorTorqueCurve = Color(0xFFFF4081)    // Electric Magenta

@Composable
fun RealtimeTelemetryDashboard(
    state: EngineState,
    onToggleExpanded: () -> Unit,
    onToggleRpm: () -> Unit,
    onToggleFuel: () -> Unit,
    onToggleTorque: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = Color(0xEC15181C) // Semi-transparent industrial HUD card
        ),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("telemetry_dashboard_card")
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            // Header Bar: Title, Live Status Indicator, & Collapse Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpanded() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ShowChart,
                        contentDescription = "Telemetry Chart",
                        tint = ImmersiveBlueContainer,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (state.language == AppLanguage.AR) "لوحة البيانات المباشرة (Live Telemetry)" else "REAL-TIME TELEMETRY DASHBOARD",
                        color = Color(0xFFE1E2E5),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    // Live blinking pulse dot
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (state.isEngineRunning) Color(0xFF00E676) else Color(0xFFFF5252))
                    )
                }

                IconButton(
                    onClick = onToggleExpanded,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = if (state.isTelemetryDashboardExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Toggle Expand",
                        tint = Color(0xFFA8ADBD)
                    )
                }
            }

            AnimatedVisibility(
                visible = state.isTelemetryDashboardExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    // Quick Stats Chips Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TelemetryMetricChip(
                            label = "RPM",
                            value = "${state.rpm.toInt()}",
                            unit = "rpm",
                            color = ColorRpmCurve,
                            visible = state.showRpmCurve,
                            onClick = onToggleRpm
                        )
                        TelemetryMetricChip(
                            label = if (state.language == AppLanguage.AR) "الوقود" else "FUEL",
                            value = String.format("%.2f", state.fuelRateLh),
                            unit = "L/h",
                            color = ColorFuelCurve,
                            visible = state.showFuelCurve,
                            onClick = onToggleFuel
                        )
                        TelemetryMetricChip(
                            label = if (state.language == AppLanguage.AR) "العزم" else "TORQUE",
                            value = String.format("%.1f", state.torqueNm.coerceAtLeast(0f)),
                            unit = "Nm",
                            color = ColorTorqueCurve,
                            visible = state.showTorqueCurve,
                            onClick = onToggleTorque
                        )
                        TelemetryMetricChip(
                            label = "BHP",
                            value = String.format("%.1f", state.brakeHorsePower),
                            unit = "hp",
                            color = Color(0xFF7C4DFF),
                            visible = true,
                            onClick = {}
                        )
                    }

                    // Main Real-Time Telemetry Curve Canvas Graph
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0D0F12))
                            .border(1.dp, Color(0xFF262B33), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        TelemetryGraphCanvas(
                            history = state.telemetryHistory,
                            showRpm = state.showRpmCurve,
                            showFuel = state.showFuelCurve,
                            showTorque = state.showTorqueCurve
                        )
                    }

                    // Chart Axis & Legend Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Axis scaling legend label
                        Text(
                            text = if (state.language == AppLanguage.AR) "مقياس: 0-1000 RPM | 0-3 L/h | 0-100 Nm" else "SCALE: 0-1000 RPM | 0-3 L/h | 0-100 Nm",
                            color = TextDim,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        // Interactive Legend Toggles
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LegendToggleDot("RPM", ColorRpmCurve, state.showRpmCurve, onToggleRpm)
                            Spacer(modifier = Modifier.width(8.dp))
                            LegendToggleDot(if (state.language == AppLanguage.AR) "الوقود" else "Fuel", ColorFuelCurve, state.showFuelCurve, onToggleFuel)
                            Spacer(modifier = Modifier.width(8.dp))
                            LegendToggleDot(if (state.language == AppLanguage.AR) "العزم" else "Torque", ColorTorqueCurve, state.showTorqueCurve, onToggleTorque)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryMetricChip(
    label: String,
    value: String,
    unit: String,
    color: Color,
    visible: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (visible) color.copy(alpha = 0.12f) else Color(0xFF1E2228))
            .border(1.dp, if (visible) color.copy(alpha = 0.4f) else Color(0xFF2D323B), RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (visible) color else TextDim)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$label: ",
                color = TextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                color = if (visible) color else TextDim,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = unit,
                color = TextDim,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun LegendToggleDot(
    label: String,
    color: Color,
    active: Boolean,
    onToggle: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clickable { onToggle() }
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(if (active) color else TextDim)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = label,
            color = if (active) Color(0xFFE1E2E5) else TextDim,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun TelemetryGraphCanvas(
    history: List<TelemetryDataPoint>,
    showRpm: Boolean,
    showFuel: Boolean,
    showTorque: Boolean
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // 1. Draw Background Grid Lines (4 horizontal reference lines)
        val gridLines = 4
        for (i in 0..gridLines) {
            val y = height * (i.toFloat() / gridLines)
            drawLine(
                color = Color(0xFF1E242C),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f
            )
        }

        if (history.isEmpty()) return@Canvas

        val maxPoints = 60
        val pointsCount = history.size
        val dx = width / (maxPoints - 1).toFloat()

        // Normalize functions:
        // RPM: 0 - 1000 RPM
        val normRpm = { rpm: Float -> (height - (rpm / 1000f).coerceIn(0f, 1f) * (height - 8f) - 4f) }
        
        // Fuel Rate: 0 - 3.0 L/h
        val normFuel = { fuel: Float -> (height - (fuel / 3.0f).coerceIn(0f, 1f) * (height - 8f) - 4f) }
        
        // Torque: 0 - 100 Nm
        val normTorque = { torque: Float -> (height - (torque / 100f).coerceIn(0f, 1f) * (height - 8f) - 4f) }

        // Start X offset so history streams from right to left smoothly
        val startXOffset = width - (pointsCount - 1) * dx

        // --- Render RPM Curve ---
        if (showRpm && pointsCount > 1) {
            val rpmPath = Path()
            val fillPath = Path()
            
            val startX = startXOffset
            val startY = normRpm(history[0].rpm)
            rpmPath.moveTo(startX, startY)
            fillPath.moveTo(startX, height)
            fillPath.lineTo(startX, startY)

            for (i in 1 until pointsCount) {
                val x = startXOffset + i * dx
                val y = normRpm(history[i].rpm)
                rpmPath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }

            val lastX = startXOffset + (pointsCount - 1) * dx
            fillPath.lineTo(lastX, height)
            fillPath.close()

            // Soft Gradient Fill under RPM
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(ColorRpmCurve.copy(alpha = 0.25f), ColorRpmCurve.copy(alpha = 0.0f)),
                    startY = 0f,
                    endY = height
                )
            )

            // Dynamic Stroke Line
            drawPath(
                path = rpmPath,
                color = ColorRpmCurve,
                style = Stroke(width = 2.2f, cap = StrokeCap.Round)
            )
        }

        // --- Render Fuel Consumption Rate Curve ---
        if (showFuel && pointsCount > 1) {
            val fuelPath = Path()
            val startX = startXOffset
            val startY = normFuel(history[0].fuelRateLh)
            fuelPath.moveTo(startX, startY)

            for (i in 1 until pointsCount) {
                val x = startXOffset + i * dx
                val y = normFuel(history[i].fuelRateLh)
                fuelPath.lineTo(x, y)
            }

            drawPath(
                path = fuelPath,
                color = ColorFuelCurve,
                style = Stroke(width = 1.8f, cap = StrokeCap.Round)
            )
        }

        // --- Render Torque Output Curve ---
        if (showTorque && pointsCount > 1) {
            val torquePath = Path()
            val startX = startXOffset
            val startY = normTorque(history[0].torqueNm)
            torquePath.moveTo(startX, startY)

            for (i in 1 until pointsCount) {
                val x = startXOffset + i * dx
                val y = normTorque(history[i].torqueNm)
                torquePath.lineTo(x, y)
            }

            drawPath(
                path = torquePath,
                color = ColorTorqueCurve,
                style = Stroke(width = 1.8f, cap = StrokeCap.Round)
            )
        }

        // Draw live glowing end node on current point
        if (pointsCount > 0) {
            val lastX = startXOffset + (pointsCount - 1) * dx
            if (showRpm) {
                val lastY = normRpm(history.last().rpm)
                drawCircle(color = ColorRpmCurve, radius = 3.5f, center = Offset(lastX, lastY))
            }
            if (showFuel) {
                val lastY = normFuel(history.last().fuelRateLh)
                drawCircle(color = ColorFuelCurve, radius = 3f, center = Offset(lastX, lastY))
            }
            if (showTorque) {
                val lastY = normTorque(history.last().torqueNm)
                drawCircle(color = ColorTorqueCurve, radius = 3f, center = Offset(lastX, lastY))
            }
        }
    }
}
