package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = BrassGold,
    onPrimary = Color.Black,
    primaryContainer = IndustrialCopper,
    onPrimaryContainer = Color.White,
    secondary = IndustrialCyan,
    onSecondary = Color.Black,
    secondaryContainer = HeavyIronGray,
    onSecondaryContainer = LightSteelHeader,
    background = IndustrialDarkBackground,
    onBackground = LightSteelHeader,
    surface = IndustrialCardSurface,
    onSurface = LightSteelHeader,
    surfaceVariant = IndustrialCardSurfaceVariant,
    onSurfaceVariant = LightSteelHeader,
    error = MeterNeedleRed,
    onError = Color.White
)

@Composable
fun ListerEngineTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

