package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.EngineComponentType
import com.example.model.EngineState
import com.example.ui.theme.ImmersiveBlueContainer
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.IndustrialCardSurface
import com.example.ui.theme.IndustrialDarkBackground
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted

@Composable
fun AssemblyWorkbench(
    state: EngineState,
    onToggleComponent: (EngineComponentType) -> Unit,
    onReassembleAll: () -> Unit,
    onSelectDetails: (EngineComponentType) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(IndustrialDarkBackground)
            .padding(16.dp)
            .testTag("assembly_workbench_view")
    ) {
        // Top Banner & Reset All Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (state.language == AppLanguage.AR) "ورشة الفك والتركيب" else "Assembly & Maintenance Workbench",
                    color = Color(0xFFE1E2E5),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (state.language == AppLanguage.AR) "انقر على القطع لفكها أو تجميعها وفحص تأثيرها" else "TAP PARTS TO DISASSEMBLE/ASSEMBLE & INSPECT BEHAVIOR",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Button(
                onClick = onReassembleAll,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2D3135),
                    contentColor = Color(0xFFE1E2E5)
                ),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF44494F)),
                modifier = Modifier.testTag("reassemble_all_button")
            ) {
                Icon(Icons.Default.Build, contentDescription = "Reset", tint = ImmersiveBlueContainer, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (state.language == AppLanguage.AR) "تجميع الكل" else "RESET ALL",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Selected Component Inspector Card (If Any Selected)
        state.selectedComponentForDetails?.let { component ->
            val isAttached = state.attachedComponents.contains(component)
            Card(
                colors = CardDefaults.cardColors(containerColor = IndustrialCardSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBlueContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = "Info", tint = ImmersiveBlueContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (state.language == AppLanguage.AR) component.nameAr else component.nameEn,
                                color = Color(0xFFE1E2E5),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        Text(
                            text = "TORQUE: ${component.torqueSpec}",
                            color = Color(0xFFFF9800),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (state.language == AppLanguage.AR) component.descriptionAr else component.descriptionEn,
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (component.isCritical)
                                (if (state.language == AppLanguage.AR) "⚠️ قطعة أساسية للتشغيل" else "CRITICAL COMPONENT")
                            else (if (state.language == AppLanguage.AR) "ℹ️ قطعة ثانوية / مساعدة" else "AUXILIARY COMPONENT"),
                            color = if (component.isCritical) Color(0xFFFF5252) else Color(0xFF00E676),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )

                        Button(
                            onClick = { onToggleComponent(component) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAttached) Color(0xFF3E0007) else Color(0xFF004A77),
                                contentColor = if (isAttached) Color(0xFFFFB4AB) else Color(0xFFD1E4FF)
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (isAttached)
                                    (if (state.language == AppLanguage.AR) "فك القطعة" else "Dismount Part")
                                else (if (state.language == AppLanguage.AR) "تركيب القطعة" else "Install Part"),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // List of all 7 Mechanical Parts
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(EngineComponentType.values()) { type ->
                val isAttached = state.attachedComponents.contains(type)
                val isSelected = state.selectedComponentForDetails == type

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF2D3135) else IndustrialCardSurface
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectDetails(type) }
                        .testTag("workbench_part_${type.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isAttached) Color(0xFF00E676) else Color(0xFFFF5252))
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = if (state.language == AppLanguage.AR) type.nameAr else type.nameEn,
                                    color = Color(0xFFE1E2E5),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = if (isAttached)
                                        (if (state.language == AppLanguage.AR) "مثبتة ومشدودة (${type.torqueSpec})" else "INSTALLED (${type.torqueSpec})")
                                    else (if (state.language == AppLanguage.AR) "مفكوكة من مكانها" else "DISMOUNTED"),
                                    color = if (isAttached) Color(0xFF00E676) else Color(0xFFFF5252),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        IconButton(
                            onClick = { onToggleComponent(type) }
                        ) {
                            Icon(
                                imageVector = if (isAttached) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = "Toggle",
                                tint = if (isAttached) Color(0xFF00E676) else Color(0xFFFF5252)
                            )
                        }
                    }
                }
            }
        }
    }
}
