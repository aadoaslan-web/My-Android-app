package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MaintenanceLog
import com.example.model.AppLanguage
import com.example.model.EngineState
import com.example.ui.theme.ImmersiveBlueContainer
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.IndustrialCardSurface
import com.example.ui.theme.IndustrialDarkBackground
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DiagnosticsView(
    state: EngineState,
    logsFlow: Flow<List<MaintenanceLog>>,
    modifier: Modifier = Modifier
) {
    val logs by logsFlow.collectAsState(initial = emptyList())
    val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(IndustrialDarkBackground)
            .padding(16.dp)
            .testTag("diagnostics_view_container")
    ) {
        Text(
            text = if (state.language == AppLanguage.AR) "لوحة التشخيص والبيانات الفيزيائية" else "Engine Diagnostics & Telemetry",
            color = Color(0xFFE1E2E5),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = if (state.language == AppLanguage.AR) "سجل الفحص وتيار الاستشعار المباشر" else "REAL-TIME SENSOR STREAM & LOGS",
            color = TextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Live Sensors Grid Card
        Card(
            colors = CardDefaults.cardColors(containerColor = IndustrialCardSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = if (state.language == AppLanguage.AR) "قراءات الحساسات الفورية" else "Real-Time Sensor Readings",
                    color = Color(0xFFE1E2E5),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    DiagnosticMetricItem(
                        icon = Icons.Default.Thermostat,
                        label = if (state.language == AppLanguage.AR) "الحرارة" else "Temperature",
                        value = "${state.temperatureCelsius.toInt()} °C",
                        color = if (state.temperatureCelsius > 95f) Color(0xFFFF5252) else Color(0xFF00E676)
                    )

                    DiagnosticMetricItem(
                        icon = Icons.Default.Speed,
                        label = if (state.language == AppLanguage.AR) "ضغط الزيت" else "Oil Pressure",
                        value = String.format("%.1f Bar", state.oilPressureBar),
                        color = ImmersiveBlueContainer
                    )

                    DiagnosticMetricItem(
                        icon = Icons.Default.Vibration,
                        label = if (state.language == AppLanguage.AR) "الاهتزاز" else "Vibration",
                        value = String.format("%.2f G", state.vibrationIntensity),
                        color = if (state.vibrationIntensity > 0.4f) Color(0xFFFF9800) else Color(0xFF00E676)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 4-Stroke Cycle Physics Telemetry Row
                Text(
                    text = if (state.language == AppLanguage.AR) "ديناميكيات الدورة الرباعية (4-Stroke Physics)" else "4-STROKE CYCLE DYNAMICS",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    DiagnosticMetricItem(
                        icon = Icons.Default.Build,
                        label = if (state.language == AppLanguage.AR) "العزم الفوري" else "Torque",
                        value = String.format("%.1f Nm", state.torqueNm),
                        color = Color(0xFFFFC107)
                    )

                    DiagnosticMetricItem(
                        icon = Icons.Default.Speed,
                        label = if (state.language == AppLanguage.AR) "ضغط الأسطوانة" else "Cyl Pressure",
                        value = String.format("%.1f Bar", state.cylinder1PressureBar),
                        color = Color(0xFF0288D1)
                    )

                    DiagnosticMetricItem(
                        icon = Icons.Default.Bolt,
                        label = if (state.language == AppLanguage.AR) "القدرة (BHP)" else "Power",
                        value = String.format("%.2f HP", state.brakeHorsePower),
                        color = Color(0xFF7C4DFF)
                    )

                    DiagnosticMetricItem(
                        icon = Icons.Default.Autorenew,
                        label = if (state.language == AppLanguage.AR) "الكفاءة" else "Efficiency",
                        value = String.format("%.1f %%", state.thermalEfficiencyPercent),
                        color = Color(0xFF00E676)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Diagnostic Message Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1A1C1E), RoundedCornerShape(8.dp))
                        .border(1.dp, ImmersiveBorder, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = if (state.language == AppLanguage.AR) state.diagnosticMessageAr else state.diagnosticMessageEn,
                        color = Color(0xFFFF9800),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // History Log List from Room DB
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Icon(Icons.Default.List, contentDescription = "Logs", tint = ImmersiveBlueContainer)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (state.language == AppLanguage.AR) "سجل الفحص والصيانة (Room DB Logs)" else "Maintenance & Assembly Log History",
                color = Color(0xFFE1E2E5),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }

        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (state.language == AppLanguage.AR) "لا يوجد سجلات صيانة بعد." else "No maintenance records yet.",
                    color = TextDim,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(logs) { log ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = IndustrialCardSurface),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ImmersiveBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (state.language == AppLanguage.AR) log.actionAr else log.actionEn,
                                    color = Color(0xFFE1E2E5),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "RPM: ${log.engineRpm.toInt()} | Status: ${log.statusSummary}",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            Text(
                                text = dateFormat.format(Date(log.timestamp)),
                                color = ImmersiveBlueContainer,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosticMetricItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(22.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, color = TextMuted, fontSize = 10.sp)
        Text(text = value, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
    }
}

