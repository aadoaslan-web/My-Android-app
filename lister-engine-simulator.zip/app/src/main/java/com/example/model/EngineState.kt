package com.example.model

enum class SimulatorTab(val titleAr: String, val titleEn: String) {
    CUTAWAY("المقطع الحي (Cutaway)", "Live Cutaway"),
    CONTROL_PANEL("لوحة الكهرباء (Control Panel)", "Generator Panel"),
    WORKBENCH("وضع الصيانة (Workbench)", "Assembly Mode"),
    DIAGNOSTICS("التشخيص والبيانات (Diagnostics)", "Diagnostics")
}

enum class AppLanguage { AR, EN }

data class TelemetryDataPoint(
    val timestampMs: Long = System.currentTimeMillis(),
    val rpm: Float = 0f,
    val fuelRateLh: Float = 0f,
    val torqueNm: Float = 0f,
    val cylinderPressureBar: Float = 1.013f
)

data class EngineState(
    // Configuration
    val cylinderConfig: CylinderConfig = CylinderConfig.SINGLE,
    val attachedComponents: Set<EngineComponentType> = EngineComponentType.values().toSet(),
    
    // Controls
    val isFuelValveOpen: Boolean = true,
    val fuelLevelPercent: Float = 85f,
    val isDecompressionLeverRaised: Boolean = false,
    val isEngineRunning: Boolean = false,
    val isHandCrankingActive: Boolean = false,
    
    // Core Dynamics
    val rpm: Float = 0f,
    val targetRpm: Float = 620f,
    val crankAngleDegrees: Float = 0f,
    val temperatureCelsius: Float = 32f,
    val oilPressureBar: Float = 0f,
    
    // Electrical & Generator
    val isCircuitBreakerClosed: Boolean = true,
    val electricalLoadWatts: Float = 1200f,
    val outputVoltage: Float = 0f,
    val outputAmperage: Float = 0f,
    val outputFrequencyHz: Float = 0f,
    val isDirectCoupling: Boolean = true,
    
    // Physics & Anomalies
    val governorThrottlePercent: Float = 50f,
    val isGovernorHunting: Boolean = false,
    val sootSmokeDensity: Float = 0.15f,
    val vibrationIntensity: Float = 0.05f,
    val torqueNm: Float = 0f,
    val fuelRateLh: Float = 0f,
    val cylinder1PressureBar: Float = 1.013f,
    val cylinder2PressureBar: Float = 1.013f,
    val loadTorqueNm: Float = 0f,
    val brakeHorsePower: Float = 0f,
    val bmepBar: Float = 0f,
    val thermalEfficiencyPercent: Float = 0f,
    val diagnosticMessageAr: String = "المحرك جاهز للتشغيل",
    val diagnosticMessageEn: String = "Engine ready for operation",
    
    // Telemetry Dashboard Overlay State
    val telemetryHistory: List<TelemetryDataPoint> = emptyList(),
    val isTelemetryDashboardExpanded: Boolean = true,
    val showRpmCurve: Boolean = true,
    val showFuelCurve: Boolean = true,
    val showTorqueCurve: Boolean = true,
    
    // UI state
    val activeTab: SimulatorTab = SimulatorTab.CUTAWAY,
    val language: AppLanguage = AppLanguage.AR,
    val selectedComponentForDetails: EngineComponentType? = null
) {
    val currentPhase: EngineFourStrokePhase
        get() = when (((crankAngleDegrees % 720f) + 720f) % 720f) {
            in 0f..180f -> EngineFourStrokePhase.INTAKE
            in 180f..360f -> EngineFourStrokePhase.COMPRESSION
            in 360f..540f -> EngineFourStrokePhase.POWER
            else -> EngineFourStrokePhase.EXHAUST
        }

    val isCylinderHeadAttached: Boolean get() = attachedComponents.contains(EngineComponentType.CYLINDER_HEAD)
    val isFuelInjectorAttached: Boolean get() = attachedComponents.contains(EngineComponentType.FUEL_INJECTOR)
    val isFuelTankAttached: Boolean get() = attachedComponents.contains(EngineComponentType.FUEL_TANK)
    val isExhaustAttached: Boolean get() = attachedComponents.contains(EngineComponentType.EXHAUST_SYSTEM)
    val isFlywheelFanAttached: Boolean get() = attachedComponents.contains(EngineComponentType.FLYWHEEL_FAN)
    val isGovernorAttached: Boolean get() = attachedComponents.contains(EngineComponentType.GOVERNOR)
    val isAlternatorBeltAttached: Boolean get() = attachedComponents.contains(EngineComponentType.ALTERNATOR_BELT)

    val canStart: Boolean
        get() = isCylinderHeadAttached && 
                isFuelInjectorAttached && 
                isFuelTankAttached && 
                isFuelValveOpen && 
                fuelLevelPercent > 0.5f && 
                isFlywheelFanAttached
}
