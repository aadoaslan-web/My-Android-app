package com.example.model

enum class EngineComponentType(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val descriptionAr: String,
    val descriptionEn: String,
    val isCritical: Boolean,
    val torqueSpec: String
) {
    CYLINDER_HEAD(
        id = "cylinder_head",
        nameAr = "رأس الأسطوانة (Cylinder Head)",
        nameEn = "Cylinder Head",
        descriptionAr = "يحتوي على صمامات السحب والعادم وغرفة الاحتراق. نزعه يمنع الانضغاط بالكامل.",
        descriptionEn = "Houses intake & exhaust valves, combustion chamber. Removal eliminates compression.",
        isCritical = true,
        torqueSpec = "110 Nm"
    ),
    FUEL_INJECTOR(
        id = "fuel_injector",
        nameAr = "حاقن الوقود (Fuel Injector)",
        nameEn = "Fuel Injector & Nozzle",
        descriptionAr = "يحقن المازوت بضغط عالٍ جداً داخل غرفة الاحتراق. نزعه يمنع دخول الوقود.",
        descriptionEn = "Atomizes diesel into combustion chamber under extreme pressure.",
        isCritical = true,
        torqueSpec = "45 Nm"
    ),
    FUEL_TANK(
        id = "fuel_tank",
        nameAr = "خزان الوقود والصنبور (Fuel Tank)",
        nameEn = "Diesel Fuel Tank & Line",
        descriptionAr = "يمد المحرك بالديزل (المازوت) عبر الجاذبية أو مضخة الضغط.",
        descriptionEn = "Stores diesel fuel and supplies gravity feed line to injection pump.",
        isCritical = true,
        torqueSpec = "25 Nm"
    ),
    EXHAUST_SYSTEM(
        id = "exhaust_system",
        nameAr = "نظام العادم والمكتّم (Exhaust & Muffler)",
        nameEn = "Exhaust Manifold & Silencer",
        descriptionAr = "يصرف الغازات المحترقة ويقلل الضوضاء. نزعه يؤدي لدخان كثيف وصوت انفجاري.",
        descriptionEn = "Expels combustion gases and reduces noise. Removal causes loud open-pipe noise.",
        isCritical = false,
        torqueSpec = "35 Nm"
    ),
    FLYWHEEL_FAN(
        id = "flywheel_fan",
        nameAr = "الفولان ومروحة التبريد (Flywheel & Cooling Fan)",
        nameEn = "Heavy Flywheel & Cooling Fan",
        descriptionAr = "الفولان الثقيل يخزن الطاقة الحركية للمحافظة على دوران 4 أشواط، والمروحة تبرد الأسطوانة.",
        descriptionEn = "Heavy momentum wheel stores energy across 4-strokes and blows cooling air.",
        isCritical = true,
        torqueSpec = "160 Nm"
    ),
    GOVERNOR(
        id = "governor",
        nameAr = "محدد السرعة الميكانيكي (Centrifugal Governor)",
        nameEn = "Mechanical Centrifugal Governor",
        descriptionAr = "يضبط ضخ الوقود تلقائياً للحفاظ على دورات ثابتة (600 RPM). نزعه يسبب تذبذب أو خروج عن السيطرة.",
        descriptionEn = "Adjusts fuel rack to balance engine RPM under fluctuating electrical load.",
        isCritical = false, // Engine runs but is unstable
        torqueSpec = "30 Nm"
    ),
    ALTERNATOR_BELT(
        id = "alternator_belt",
        nameAr = "سير المولد الكهربائي (Alternator Belt)",
        nameEn = "Generator Drive Belt / Coupling",
        descriptionAr = "ينقل الحركة من عمود المحرك إلى الدينامو لتوليد الكهرباء.",
        descriptionEn = "Transfers mechanical rotary power from engine flywheel to electrical alternator.",
        isCritical = false,
        torqueSpec = "Tension ~ 15mm deflection"
    )
}

enum class CylinderConfig(val count: Int, val labelAr: String, val labelEn: String) {
    SINGLE(1, "أسطوانة واحدة (Lister CS 6/1)", "Single Cylinder (CS 6/1)"),
    TWIN(2, "أسطوانتان (Lister CS 12/2)", "Twin Cylinder (CS 12/2)")
}

enum class EngineFourStrokePhase(val labelAr: String, val labelEn: String) {
    INTAKE("شوط السحب (Intake)", "Intake Stroke"),
    COMPRESSION("شوط الانضغاط (Compression)", "Compression Stroke"),
    POWER("شوط القدرة/الاشتغال (Power)", "Power/Combustion Stroke"),
    EXHAUST("شوط العادم (Exhaust)", "Exhaust Stroke")
}
