package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MaintenanceDao {
    @Query("SELECT * FROM maintenance_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<MaintenanceLog>>

    @Insert
    suspend fun insertLog(log: MaintenanceLog)

    @Query("DELETE FROM maintenance_logs")
    suspend fun clearLogs()
}
