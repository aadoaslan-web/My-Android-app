package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "maintenance_logs")
data class MaintenanceLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val actionAr: String,
    val actionEn: String,
    val componentId: String,
    val engineRpm: Float,
    val statusSummary: String
)
