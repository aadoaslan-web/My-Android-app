package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

class FourStrokeSoundPoolEngine(private val context: Context) {

    private var soundPool: SoundPool? = null
    private var soundIntakeId: Int = 0
    private var soundCompressionId: Int = 0
    private var soundCombustionId: Int = 0
    private var soundExhaustId: Int = 0

    private var lastPhase = -1

    init {
        initSoundPool()
    }

    private fun initSoundPool() {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            soundPool = SoundPool.Builder()
                .setMaxStreams(8)
                .setAudioAttributes(audioAttributes)
                .build()

            // Generate synthetic 4-stroke phase PCM WAV files
            val intakeFile = generateSampleFile("sound_intake.wav", ::generateIntakePcm)
            val compressionFile = generateSampleFile("sound_compression.wav", ::generateCompressionPcm)
            val combustionFile = generateSampleFile("sound_combustion.wav", ::generateCombustionPcm)
            val exhaustFile = generateSampleFile("sound_exhaust.wav", ::generateExhaustPcm)

            soundIntakeId = soundPool?.load(intakeFile.absolutePath, 1) ?: 0
            soundCompressionId = soundPool?.load(compressionFile.absolutePath, 1) ?: 0
            soundCombustionId = soundPool?.load(combustionFile.absolutePath, 1) ?: 0
            soundExhaustId = soundPool?.load(exhaustFile.absolutePath, 1) ?: 0

        } catch (e: Exception) {
            Log.e("SoundPoolEngine", "Error initializing SoundPool: ${e.message}")
        }
    }

    private fun generateSampleFile(filename: String, pcmGenerator: () -> ShortArray): File {
        val file = File(context.cacheDir, filename)
        if (file.exists()) return file

        val pcmData = pcmGenerator()
        val sampleRate = 22050
        val byteRate = sampleRate * 2
        val dataSize = pcmData.size * 2
        val totalSize = 36 + dataSize

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt(totalSize)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16) // Subchunk1Size (16 for PCM)
            putShort(1.toShort()) // AudioFormat (1 for PCM)
            putShort(1.toShort()) // NumChannels (1 for Mono)
            putInt(sampleRate)
            putInt(byteRate)
            putShort(2.toShort()) // BlockAlign
            putShort(16.toShort()) // BitsPerSample
            put("data".toByteArray())
            putInt(dataSize)
        }.array()

        FileOutputStream(file).use { fos ->
            fos.write(header)
            val buffer = ByteBuffer.allocate(pcmData.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (sample in pcmData) {
                buffer.putShort(sample)
            }
            fos.write(buffer.array())
        }
        return file
    }

    // Intake: Smooth air suction whoosh (120ms duration)
    private fun generateIntakePcm(): ShortArray {
        val count = 2640 // ~120ms at 22050Hz
        val samples = ShortArray(count)
        val random = Random(42)
        for (i in 0 until count) {
            val t = i.toFloat() / count
            val envelope = sin(t * PI.toFloat())
            val noise = (random.nextFloat() * 2f - 1f) * 0.4f
            val sine = sin(2.0 * PI * i * 140.0 / 22050.0).toFloat() * 0.6f
            samples[i] = ((sine + noise) * envelope * 20000f).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    // Compression: Rising frequency pressure whistle/creak (100ms duration)
    private fun generateCompressionPcm(): ShortArray {
        val count = 2205 // ~100ms at 22050Hz
        val samples = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val t = i.toFloat() / count
            val freq = 120.0 + t * 280.0 // 120Hz -> 400Hz
            phase += freq / 22050.0
            val envelope = sin(t * PI.toFloat())
            val sampleVal = sin(2.0 * PI * phase).toFloat() * envelope
            samples[i] = (sampleVal * 18000f).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    // Combustion: Heavy diesel detonation pop/thump (150ms duration)
    private fun generateCombustionPcm(): ShortArray {
        val count = 3307 // ~150ms at 22050Hz
        val samples = ShortArray(count)
        val random = Random(1337)
        for (i in 0 until count) {
            val t = i.toFloat() / count
            val envelope = exp(-t * 12.0f) // Sharp attack, quick exponential decay
            val bassPop = sin(2.0 * PI * i * 55.0 / 22050.0).toFloat() * 0.7f
            val crackle = (random.nextFloat() * 2f - 1f) * 0.4f
            samples[i] = ((bassPop + crackle) * envelope * 32000f).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    // Exhaust: High pressure gas blow-off blast (120ms duration)
    private fun generateExhaustPcm(): ShortArray {
        val count = 2640 // ~120ms at 22050Hz
        val samples = ShortArray(count)
        val random = Random(99)
        for (i in 0 until count) {
            val t = i.toFloat() / count
            val envelope = exp(-t * 10.0f) * sin(t * PI.toFloat())
            val noise = (random.nextFloat() * 2f - 1f) * 0.8f
            val rumble = sin(2.0 * PI * i * 85.0 / 22050.0).toFloat() * 0.3f
            samples[i] = ((noise + rumble) * envelope * 26000f).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    fun updateState(crankAngleDegrees: Float, rpm: Float, isRunning: Boolean, load: Float, exhaustAttached: Boolean) {
        if (!isRunning || rpm < 30f) {
            lastPhase = -1
            return
        }

        val normalizedAngle = ((crankAngleDegrees % 720f) + 720f) % 720f
        val currentPhase = when {
            normalizedAngle < 180.0f -> 0 // Intake
            normalizedAngle < 360.0f -> 1 // Compression
            normalizedAngle < 540.0f -> 2 // Combustion
            else -> 3 // Exhaust
        }

        if (currentPhase != lastPhase) {
            lastPhase = currentPhase
            playStrokeSample(currentPhase, rpm, load, exhaustAttached)
        }
    }

    private fun playStrokeSample(phase: Int, rpm: Float, load: Float, exhaustAttached: Boolean) {
        val soundId = when (phase) {
            0 -> soundIntakeId
            1 -> soundCompressionId
            2 -> soundCombustionId
            3 -> soundExhaustId
            else -> 0
        }

        if (soundId == 0) return

        val rate = (rpm / 600f).coerceIn(0.5f, 2.0f)
        val loadFactor = load.coerceIn(0.3f, 1.2f)

        val volume = when (phase) {
            0 -> 0.4f * loadFactor
            1 -> 0.5f * loadFactor
            2 -> 0.95f * loadFactor
            3 -> if (exhaustAttached) 0.65f * loadFactor else 1.0f * loadFactor
            else -> 0.5f
        }.coerceIn(0.05f, 1.0f)

        soundPool?.play(soundId, volume, volume, 1, 0, rate)
    }

    fun stop() {
        lastPhase = -1
        try {
            soundPool?.autoPause()
        } catch (e: Exception) {
            Log.e("SoundPoolEngine", "Error auto-pausing SoundPool: ${e.message}")
        }
    }

    fun release() {
        try {
            soundPool?.release()
            soundPool = null
        } catch (e: Exception) {
            Log.e("SoundPoolEngine", "Error releasing SoundPool: ${e.message}")
        }
    }
}
