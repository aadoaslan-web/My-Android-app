package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

class DieselAudioEngine(context: Context) {
    private var audioTrack: AudioTrack? = null
    private var audioJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    private val soundPoolEngine = FourStrokeSoundPoolEngine(context)

    @Volatile
    private var isPlaying = false

    @Volatile
    private var currentRpm = 0f

    @Volatile
    private var isExhaustAttached = true

    @Volatile
    private var loadFactor = 0.5f

    fun start() {
        if (isPlaying) return
        isPlaying = true
        
        val sampleRate = 22050
        val bufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ) * 2

        try {
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()

            audioJob = scope.launch {
                val samples = ShortArray(1024)
                var phase = 0.0
                var pulsePhase = 0.0

                while (isActive && isPlaying) {
                    val rpm = currentRpm.coerceAtLeast(50f)
                    val revsPerSec = rpm / 60f
                    // 4-stroke single cylinder: 1 power stroke every 2 revolutions
                    val firingFreq = (revsPerSec / 2.0).coerceAtLeast(0.5)
                    val baseToneFreq = if (isExhaustAttached) 65.0 else 120.0

                    for (i in samples.indices) {
                        pulsePhase += firingFreq / sampleRate
                        if (pulsePhase >= 1.0) {
                            pulsePhase -= 1.0
                        }

                        // Power stroke impulse envelope (sharp attack, exponential decay)
                        val impulse = if (pulsePhase < 0.25) {
                            val t = pulsePhase / 0.25
                            (1.0 - t) * (1.0 - t) * sin(2.0 * Math.PI * t * 3.0)
                        } else {
                            0.0
                        }

                        // Base engine hum
                        phase += baseToneFreq / sampleRate
                        if (phase >= 1.0) phase -= 1.0
                        val engineHum = sin(2.0 * Math.PI * phase) * 0.15

                        // Exhaust noise
                        val exhaustHarshness = if (isExhaustAttached) 0.6 else 1.8
                        val sampleValue = (impulse * exhaustHarshness + engineHum * loadFactor) * 32767.0
                        samples[i] = sampleValue.coerceIn(-32767.0, 32767.0).toInt().toShort()
                    }

                    audioTrack?.write(samples, 0, samples.size)
                }
            }
        } catch (e: Exception) {
            Log.e("DieselAudioEngine", "AudioTrack creation failed: ${e.message}")
        }
    }

    fun updateState(rpm: Float, crankAngleDegrees: Float, exhaustAttached: Boolean, load: Float) {
        currentRpm = rpm
        isExhaustAttached = exhaustAttached
        loadFactor = load.coerceIn(0.2f, 1.5f)
        
        soundPoolEngine.updateState(
            crankAngleDegrees = crankAngleDegrees,
            rpm = rpm,
            isRunning = rpm > 30f,
            load = loadFactor,
            exhaustAttached = exhaustAttached
        )

        if (rpm > 20f && !isPlaying) {
            start()
        } else if (rpm <= 20f && isPlaying) {
            stop()
        }
    }

    fun stop() {
        isPlaying = false
        audioJob?.cancel()
        audioJob = null
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            // Ignore release errors
        }
        audioTrack = null
        soundPoolEngine.stop()
    }

    fun release() {
        stop()
        soundPoolEngine.release()
    }
}
